#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle ontbreekt. Open dit project in Android Studio of gebruik de GitHub Actions-workflow." >&2
  exit 1
fi
if [[ -z "${ANDROID_HOME:-}${ANDROID_SDK_ROOT:-}" ]]; then
  echo "ANDROID_HOME of ANDROID_SDK_ROOT ontbreekt. Installeer eerst de Android SDK." >&2
  exit 1
fi
gradle :app:assembleDebug --no-daemon
printf '\nGereed: app/build/outputs/apk/debug/app-debug.apk\n'

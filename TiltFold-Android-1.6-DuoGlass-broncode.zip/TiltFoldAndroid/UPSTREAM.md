# Basis en licenties

De Glass-rendering in TiltFold DuoGlass is een zelfstandige Android-implementatie van het publiek gedocumenteerde optical glass / projection-model van de Duo-familie. De broncode in `DuoGlassShader.java` is speciaal voor TiltFold geschreven. Er zijn **geen letterlijke bronbestanden** uit de projecten opgenomen. Het project bevat geen schermopname, accessibility service, Shizuku of overlay.

De publieke projecten en hun MIT-licenties (geraadpleegd 28 oktober 2026):

- https://github.com/marcoazeem/duo-open (MIT)
- https://github.com/joeconsorti/duo-fold-live (MIT)
- https://github.com/jcx396905-gif/DuoFold-Android (MIT)
- https://github.com/maheshj01/ifold-mac (MIT)

De werking op een niet-opvouwbaar toestel is anders: de beweging komt van de kantelsensor. Het effect is beperkt tot de live achtergrond en de fullscreen voorvertoning. De originele apps gebruiken soms hoge toegangsrechten of vouwsensoren; die onderdelen zijn bewust niet overgenomen.

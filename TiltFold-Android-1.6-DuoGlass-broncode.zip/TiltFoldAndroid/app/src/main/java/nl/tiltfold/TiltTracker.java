package nl.tiltfold;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.Surface;
import android.view.WindowManager;

/** A smoothed roll angle. Calibration is stored locally and shared with the wallpaper. */
final class TiltTracker implements SensorEventListener {
    static final String CALIBRATION = "calibration_radians";
    static final String CALIBRATION_PITCH = "calibration_pitch_radians";
    static final String PITCH_MODE = "pitch_mode";

    private final SensorManager manager;
    private final Sensor sensor;
    private final WindowManager windowManager;
    private final SharedPreferences prefs;
    private final Runnable onUpdate;
    private final boolean gravityFallback;
    private boolean hasReading;
    private float reference;
    private float latest;
    private float filtered;
    private boolean lastPitchMode;

    TiltTracker(Context context, Runnable onUpdate) {
        manager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        prefs = context.getSharedPreferences(FoldRenderer.PREFS, Context.MODE_PRIVATE);
        Sensor chosen = null;
        if (manager != null) {
            chosen = manager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
            if (chosen == null) chosen = manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            if (chosen == null) chosen = manager.getDefaultSensor(Sensor.TYPE_GRAVITY);
            if (chosen == null) chosen = manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        }
        sensor = chosen;
        gravityFallback = chosen != null &&
                (chosen.getType() == Sensor.TYPE_GRAVITY || chosen.getType() == Sensor.TYPE_ACCELEROMETER);
        this.onUpdate = onUpdate;
        lastPitchMode = prefs.getBoolean(PITCH_MODE, false);
        reloadCalibration();
    }

    void start() {
        reloadCalibration();
        if (sensor != null) manager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME);
    }

    void stop() {
        if (manager != null) manager.unregisterListener(this);
    }

    boolean hasSensor() { return sensor != null; }

    void calibrate() {
        if (!hasReading) return;
        reference = latest;
        filtered = 0;
        prefs.edit().putFloat(calibrationKey(), latest).apply();
        onUpdate.run();
    }

    private String calibrationKey() {
        return prefs.getBoolean(PITCH_MODE, false) ? CALIBRATION_PITCH : CALIBRATION;
    }

    void reloadCalibration() {
        lastPitchMode = prefs.getBoolean(PITCH_MODE, false);
        String key = calibrationKey();
        if (prefs.contains(key)) {
            reference = prefs.getFloat(key, 0);
            hasReading = true;
        } else {
            hasReading = false;
            filtered = 0f;
        }
    }

    float getDegrees() { return filtered; }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    @Override public void onSensorChanged(SensorEvent event) {
        boolean pitchMode = prefs.getBoolean(PITCH_MODE, false);
        if (pitchMode != lastPitchMode) reloadCalibration();
        float angle;
        if (gravityFallback) {
            angle = pitchMode
                    ? (float) Math.atan2(-event.values[1],
                        Math.hypot(event.values[0], event.values[2]))
                    : (float) Math.atan2(event.values[0],
                        Math.hypot(event.values[1], event.values[2]));
        } else {
            float[] matrix = new float[9];
            float[] remapped = new float[9];
            float[] orientation = new float[3];
            SensorManager.getRotationMatrixFromVector(matrix, event.values);
            int rotation = Surface.ROTATION_0;
            try { rotation = windowManager.getDefaultDisplay().getRotation(); }
            catch (Exception ignored) {}
            int x = SensorManager.AXIS_X;
            int y = SensorManager.AXIS_Y;
            if (rotation == Surface.ROTATION_90) { x = SensorManager.AXIS_Y; y = SensorManager.AXIS_MINUS_X; }
            else if (rotation == Surface.ROTATION_180) { x = SensorManager.AXIS_MINUS_X; y = SensorManager.AXIS_MINUS_Y; }
            else if (rotation == Surface.ROTATION_270) { x = SensorManager.AXIS_MINUS_Y; y = SensorManager.AXIS_X; }
            SensorManager.remapCoordinateSystem(matrix, x, y, remapped);
            SensorManager.getOrientation(remapped, orientation);
            angle = pitchMode ? orientation[1] : orientation[2];
        }
        latest = angle;
        if (!hasReading) { reference = latest; hasReading = true; }
        float delta = (float) Math.toDegrees(Math.atan2(
                Math.sin(latest - reference), Math.cos(latest - reference)));
        delta = Math.max(-65f, Math.min(65f, delta));
        float before = filtered;
        // Quick sensor denoising, followed by an independent display-frame spring.
        // Avoid compounding heavy smoothing (which feels delayed when you tilt).
        float change = Math.abs(delta - filtered);
        filtered += (delta - filtered) * (change > 2f ? .47f : .28f);
        if (Math.abs(before - filtered) >= .065f) onUpdate.run();
    }
}

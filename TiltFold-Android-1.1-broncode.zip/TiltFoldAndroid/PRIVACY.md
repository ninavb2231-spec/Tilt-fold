# Privacy van TiltFold

TiltFold is een volledig offline Android-live-wallpaper-app. De broncode bevat geen internettoegang, statistiek, tracking, advertenties, accounts of externe SDK.

## Verwerkte gegevens

- De apparaatrotatie wordt in het geheugen gelezen om de vouwstand te berekenen; sensorgegevens worden niet naar een server verzonden.
- De laatst door de gebruiker gekozen achtergrondfoto wordt door de app via de Android-documentkiezer geopend. De app bewaart alleen de lokale document-URI om de gekozen foto opnieuw te kunnen openen.
- De neutrale sensorstand en de gevoeligheid/richting worden lokaal opgeslagen in Android SharedPreferences.

## Toegang

De app heeft geen `uses-permission`-verzoeken. De wallpaper-service is beveiligd met `android.permission.BIND_WALLPAPER`, zoals Android vereist voor live wallpapers. Die serviceverklaring geeft TiltFold geen speciale toegang tot andere apps.

## Verwijderen

Verwijder TiltFold via Android Instellingen > Apps. De lokaal opgeslagen appinstellingen verdwijnen bij het wissen van de appgegevens of verwijderen van de app. Eventuele toestemming voor de gekozen foto wordt niet langer gebruikt.

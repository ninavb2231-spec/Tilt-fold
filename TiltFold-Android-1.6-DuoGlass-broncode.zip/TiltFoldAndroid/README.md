# TiltFold 1.6 · DuoGlass

**Full-screen frosted fold** voor Android 13+ (GPU-shader); bevat een Canvas-fallback op oudere toestellen.

Belangrijkste verschillen met SilkFold:

- De foto **blijft altijd het gehele scherm vullen**, zonder inset, zwarte achtergrond of uitgesneden beeld.
- De vervaging gebeurt in de afbeeldingsshader zelf, met 13 jittered samples per pixel.
- Blur, schaduwwerking, opale tint en reflectie nemen geleidelijk toe met kanteling en afstand tot de virtuele scharnierzijde.
- Maakt gebruik van `SurfaceHolder.lockHardwareCanvas()` zodat de GPU-shader ook in live wallpaper werkt.
- Veeranimatie en instellingen van eerdere TiltFold-versies, met fullscreen-preview.

## Veiligheid

Geen `<uses-permission>` in het AndroidManifest. Geen INTERNET, accessibility, overlay, Shizuku, MediaProjection of scherminhoud van andere apps. Foto's worden alleen lokaal uit de Android-fotokiezer gelezen.

## Maken via GitHub Actions

Upload `TiltFold-Android-1.6-DuoGlass-broncode.zip` naar de repository-root, kopieer `build-apk.yml` naar `.github/workflows/build-apk.yml`, commit **directly to main**, en start onder Actions de workflow `Bouw TiltFold DuoGlass 1.6`. Download het artifact `TiltFold-DUOGLASS-1.6-APK` en pak de ZIP uit. Installeer `TiltFold-DuoGlass-1.6.apk`.

## Vermelding broncode

Zie `UPSTREAM.md`. De shader is een nieuwe implementatie op basis van de openbare optische beschrijvingen van de Duo-projecten. **Geen letterlijke kopie** van de aangeleverde repositories; de upstream Android-services zouden niet werken zonder gevoelige rechten.

Ongetest op een fysiek toestel. Een geslaagde GitHub-build bevestigt de Android-compileerstap, maar niet het uiterlijk of de GPU-compatibiliteit van een specifieke telefoon.

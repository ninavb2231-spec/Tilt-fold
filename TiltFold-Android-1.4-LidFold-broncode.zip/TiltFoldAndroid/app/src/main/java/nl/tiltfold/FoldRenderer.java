package nl.tiltfold;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.net.Uri;

import java.io.InputStream;
import java.util.Random;

/**
 * TiltFold 1.4: an original Android interpretation of the iFold Mac flexible sheet.
 * 3D-inspired 2D projection using a continuous image mesh hinged at the bottom.
 * The wallpaper is never captured and no special permissions are requested.
 */
final class FoldRenderer {
    static final String PREFS = "tiltfold";
    static final String IMAGE = "image";
    static final String STRENGTH = "strength";
    static final String REVERSED = "reversed";
    static final String GLASS = "glass_level";
    static final String DEPTH = "fold_depth";

    // Mesh vertices are connected. There is no separate left or right panel, and no centre seam.
    private static final int COLUMNS = 10;
    private static final int ROWS = 44;
    private final float[] vertices = new float[(COLUMNS + 1) * (ROWS + 1) * 2];
    private final int[] softColors = new int[(COLUMNS + 1) * (ROWS + 1)];
    private final int[] strongColors = new int[(COLUMNS + 1) * (ROWS + 1)];
    private final float[] projectedY = new float[ROWS + 1];
    private final float[] projectedScale = new float[ROWS + 1];
    private final float[] projectedOffset = new float[ROWS + 1];

    private final Context context;
    private final Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint glassPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Path silhouette = new Path();
    private Bitmap scene, blurSoft, blurMedium, blurStrong, noise;
    private BitmapShader softShader, mediumShader, strongShader, noiseShader;
    private int width, height;
    private String lastUri;

    FoldRenderer(Context context) { this.context = context.getApplicationContext(); }

    void invalidateArtwork() {
        recycle(scene); recycle(blurSoft); recycle(blurMedium); recycle(blurStrong);
        scene = blurSoft = blurMedium = blurStrong = null;
        softShader = mediumShader = strongShader = null;
    }

    private static void recycle(Bitmap bmp) { if (bmp != null && !bmp.isRecycled()) bmp.recycle(); }
    private static float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }
    private static float smooth(float x) { x = clamp(x); return x*x*(3f-2f*x); }
    private static int opacity(float a) {
        return (Math.round(clamp(a) * 255f) << 24) | 0x00FFFFFF;
    }

    /** degree is the spring-smoothed tilt; speed is degrees / second. */
    void draw(Canvas canvas, float degrees, float speed) {
        int w = canvas.getWidth();
        int h = canvas.getHeight();
        ensureBitmaps(w, h);
        if (scene == null) return;

        SharedPreferences prefs = context.getSharedPreferences(PREFS, 0);
        float sensitivity = prefs.getInt(STRENGTH, 100) / 100f;
        float glass = clamp(prefs.getInt(GLASS, 84) / 100f);
        float depth = clamp(prefs.getInt(DEPTH, 75) / 100f);
        if (prefs.getBoolean(REVERSED, false)) degrees = -degrees;
        float direction = degrees >= 0f ? 1f : -1f;
        float amount = smooth(Math.abs(degrees) * sensitivity / 52f);

        imagePaint.setAlpha(255);
        if (amount < .0003f) {
            canvas.drawBitmap(scene, 0f, 0f, imagePaint);
            return;
        }

        // A dim, heavily defocused scene sits behind the sheet, analogous to the
        // space revealed as a laptop lid moves away from the viewer.
        canvas.drawBitmap(blurStrong, 0f, 0f, imagePaint);
        glassPaint.setShader(null);
        glassPaint.setColor(Color.argb(Math.round(110f + 95f*amount), 3, 9, 23));
        canvas.drawRect(0f, 0f, w, h, glassPaint);

        // Project a curved sheet from its bottom hinge, row by row.
        // Integrate cos(theta) for height and sin(theta) for distance to camera.
        // This avoids the seam and sharp crease produced by two independent panels.
        double length = 0d;
        double toward = 0d;
        final double step = h / (double) ROWS;
        final float turn = (float) ((0.77d + 0.59d*depth) * amount);
        for (int bottomIndex = 0; bottomIndex <= ROWS; bottomIndex++) {
            int row = ROWS - bottomIndex;
            if (bottomIndex > 0) {
                float u = (bottomIndex - .5f) / ROWS;
                double bend = turn * (.13 + .87*Math.pow(u, .75 + (1f-depth)*1.35));
                length += step * Math.cos(bend);
                toward += step * Math.sin(bend);
            }
            float cameraScale = (float)(2.4*h / (2.4*h + toward*.62));
            projectedY[row] = h - (float)(length * cameraScale);
            projectedScale[row] = cameraScale;
            projectedOffset[row] = direction * (float)(toward/h) * w*.045f;
        }

        final float topShift = projectedY[0];
        final float travel = clamp(Math.abs(speed)/160f);
        final float blurStrength = glass * smooth(amount*.94f + .10f*travel);
        for (int row = 0; row <= ROWS; row++) {
            float fromBottom = 1f - row / (float)ROWS;
            float s = projectedScale[row];
            float rowY = projectedY[row];
            float offset = projectedOffset[row];
            // Non-uniform frost through the surface: stronger toward the lid's top.
            float edge = smooth((fromBottom-.08f)/.90f);
            float soft = blurStrength*(.12f + .39f*edge) * (1f-.28f*amount);
            float strong = blurStrength*(.11f + .77f*edge) * smooth(amount*.95f + travel*.22f);
            for (int col = 0; col <= COLUMNS; col++) {
                int i = row*(COLUMNS+1)+col;
                float x = w*col/(float)COLUMNS;
                vertices[2*i] = w*.5f + (x-w*.5f)*s + offset;
                vertices[2*i+1] = rowY;
                softColors[i] = opacity(soft);
                strongColors[i] = opacity(strong);
            }
        }

        // Paint all versions on exactly the same continuous geometry.
        // Bitmap mesh colours multiply the bitmap opacity at each vertex,
        // which gives the frost a smooth spatial fade with no strip boundaries.
        imagePaint.setColor(Color.WHITE);
        imagePaint.setAlpha(255);
        canvas.drawBitmapMesh(scene, COLUMNS, ROWS, vertices, 0, null, 0, imagePaint);
        if (glass > .005f) {
            canvas.drawBitmapMesh(blurSoft, COLUMNS, ROWS, vertices, 0, softColors, 0, imagePaint);
            canvas.drawBitmapMesh(blurStrong, COLUMNS, ROWS, vertices, 0, strongColors, 0, imagePaint);
        }

        // Exact silhouette of the projected sheet, used to clip its lighting.
        silhouette.reset();
        silhouette.moveTo(vertices[0], vertices[1]);
        for (int row=1; row<=ROWS; row++) {
            int i = 2*row*(COLUMNS+1);
            silhouette.lineTo(vertices[i], vertices[i+1]);
        }
        for (int row=ROWS; row>=0; row--) {
            int i = 2*(row*(COLUMNS+1) + COLUMNS);
            silhouette.lineTo(vertices[i], vertices[i+1]);
        }
        silhouette.close();
        canvas.save();
        canvas.clipPath(silhouette);

        // Lambert-inspired shade: parts facing away from the viewer get darker.
        glassPaint.setColor(Color.WHITE);
        glassPaint.setAlpha(255);
        glassPaint.setShader(new LinearGradient(0f, topShift, 0f, h,
                new int[] { Color.argb(Math.round(130*amount), 0, 3, 16),
                            Color.argb(Math.round(46*amount), 0, 5, 20),
                            Color.TRANSPARENT },
                new float[] {0f, .52f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0f, 0f, w, h, glassPaint);

        // An oversized, soft specular sheen. No visible hinge/centre stroke.
        float highlight = w*(.43f + .20f*direction*amount);
        glassPaint.setShader(new LinearGradient(highlight-w*.65f, h*.14f,
                highlight+w*.65f, h*.86f,
                new int[] {Color.TRANSPARENT,
                    Color.argb(Math.round(24*amount*glass), 234, 246, 255),
                    Color.argb(Math.round(54*amount*glass), 238, 247, 255),
                    Color.argb(Math.round(17*amount*glass), 224, 236, 255),
                    Color.TRANSPARENT},
                new float[] {0f,.28f,.49f,.75f,1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0f, 0f, w, h, glassPaint);
        glassPaint.setShader(null);
        canvas.restore();
    }

    private void ensureBitmaps(int w, int h) {
        if (w < 2 || h < 2) return;
        String uri = context.getSharedPreferences(PREFS, 0).getString(IMAGE, "");
        if (uri == null) uri = "";
        if (scene != null && w == width && h == height && uri.equals(lastUri)) return;
        invalidateArtwork();
        width = w;
        height = h;
        lastUri = uri;
        scene = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(scene);
        drawDefaultBackground(c, w, h);
        if (!uri.isEmpty()) {
            try (InputStream input = context.getContentResolver().openInputStream(Uri.parse(uri))) {
                if (input != null) {
                    BitmapFactory.Options bounds = new BitmapFactory.Options();
                    bounds.inJustDecodeBounds = true;
                    try (InputStream boundStream = context.getContentResolver()
                            .openInputStream(Uri.parse(uri))) {
                        if (boundStream != null) BitmapFactory.decodeStream(boundStream, null, bounds);
                    }
                    int sample = 1;
                    while (bounds.outWidth > 0 && bounds.outHeight > 0 &&
                            (bounds.outWidth / sample > w * 2 || bounds.outHeight / sample > h * 2)) {
                        sample *= 2;
                    }
                    BitmapFactory.Options actual = new BitmapFactory.Options();
                    actual.inSampleSize = sample;
                    Bitmap photo = BitmapFactory.decodeStream(input, null, actual);
                    if (photo != null) {
                        float scale = Math.max(w / (float) photo.getWidth(), h / (float) photo.getHeight());
                        float dw = photo.getWidth() * scale;
                        float dh = photo.getHeight() * scale;
                        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                        c.drawBitmap(photo, null, new RectF((w - dw) / 2, (h - dh) / 2,
                                (w + dw) / 2, (h + dh) / 2), p);
                        photo.recycle();
                    }
                }
            } catch (Exception ignored) { /* Keep built-in scene when an image is unavailable. */ }
        }
        blurSoft = blurry(scene, 12);
        blurMedium = blurry(scene, 27);
        blurStrong = blurry(scene, 58);
        softShader = new BitmapShader(blurSoft, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        mediumShader = new BitmapShader(blurMedium, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        strongShader = new BitmapShader(blurStrong, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
    }

    /** Pre-render blur textures once per artwork change, never inside a frame. */
    private static Bitmap blurry(Bitmap original, int factor) {
        int w = original.getWidth(), h = original.getHeight();
        Bitmap tiny = Bitmap.createScaledBitmap(original, Math.max(1, w / factor),
                Math.max(1, h / factor), true);
        Bitmap intermediate = Bitmap.createScaledBitmap(tiny, Math.max(1, w / 5),
                Math.max(1, h / 5), true);
        Bitmap soft = Bitmap.createScaledBitmap(intermediate, w, h, true);
        if (tiny != original && tiny != soft) tiny.recycle();
        if (intermediate != original && intermediate != soft) intermediate.recycle();
        return soft;
    }

    private void ensureNoise() {
        if (noise != null && !noise.isRecycled()) return;
        Random random = new Random(41012);
        int size = 96;
        int[] pixels = new int[size * size];
        for (int i = 0; i < pixels.length; i++) {
            pixels[i] = (random.nextBoolean() ? 0x0FFFFFFF : 0x0A000000);
        }
        noise = Bitmap.createBitmap(pixels, size, size, Bitmap.Config.ARGB_8888);
        noiseShader = new BitmapShader(noise, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
    }

    private static void drawDefaultBackground(Canvas c, int w, int h) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, w, h,
                new int[]{0xFF06131D, 0xFF113B64, 0xFF4E2D79, 0xFF140C27},
                new float[]{0f, .34f, .69f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(new RadialGradient(.18f * w, .30f * h, .72f * w,
                new int[]{0xD92FEEDE, 0x0059A0FF}, null, Shader.TileMode.CLAMP));
        c.drawCircle(.18f * w, .30f * h, .72f * w, p);
        p.setShader(new RadialGradient(.89f * w, .73f * h, .83f * w,
                new int[]{0xBDEE5AC4, 0x00F95799}, null, Shader.TileMode.CLAMP));
        c.drawCircle(.89f * w, .73f * h, .83f * w, p);
        Random random = new Random(4101);
        p.setShader(null);
        for (int i = 0; i < 110; i++) {
            p.setColor(0x66FFFFFF);
            c.drawCircle(random.nextFloat() * w, random.nextFloat() * h,
                    .5f + random.nextFloat() * 1.9f, p);
        }
        p.setColor(0x33FFFFFF);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(w * .0023f);
        for (int i = 1; i <= 4; i++) {
            float radius = w * (.24f + .17f * i);
            c.drawCircle(w * .52f, h * .50f, radius, p);
        }
        p.setStyle(Paint.Style.FILL);
    }
}

# Security

Geen <uses-permission>-regels in AndroidManifest.xml. De Android wallpaperservice gebruikt android.permission.BIND_WALLPAPER als *service-beveiliging*, niet als door de app gevraagde toestemming. Het project downloadt in GitHub Actions alleen Android/Gradle-builddependencies via standaard tooling. Debug-APK's hebben een buildgebonden handtekening; daarom wordt deze variant als afzonderlijke app met package nl.tiltfold.frostfade geïnstalleerd. Controleer de buildstatus en de inhoud vóór installatie.

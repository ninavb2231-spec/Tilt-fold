# TiltFold voor Android

Android live wallpaper met een iPhone Duo/Fold-achtige, door kanteling aangestuurde vouwillusie. Zelfstandig voorbeeldproject, zonder Apple-materiaal of externe SDK's. **Dit project is niet gelieerd aan Apple.**

## Functies

- Kantel naar links of rechts: de ene schermhelft vouwt visueel naar binnen.
- Onscherpte (frosted glass), diepteschaduw en lichte glans volgen de hoek.
- Kalibreer de stand waarin je telefoon plat/ongeplooid moet lijken.
- Stel de gevoeligheid in van 20% tot 200%.
- Kies een eigen foto via de Android bestandskiezer, of gebruik de meegeleverde abstracte achtergrond.
- Stel het effect in als een Android live wallpaper voor je startscherm en eventueel vergrendelscherm.
- Geen internet-, camera-, opslag-, toegankelijkheids- of overlaytoestemmingen nodig.

## Hoe maak je een APK?

1. Installeer **Android Studio** op een computer.
2. Kies **Open** en selecteer de map `TiltFoldAndroid`.
3. Laat Android Studio Gradle en Android SDK Platform 35 installeren/synchroniseren.
4. Kies **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Het APK-bestand komt onder `app/build/outputs/apk/debug/app-debug.apk` te staan.
6. Kopieer het APK-bestand naar je telefoon en installeer het.

Voor een releaseversie moet je zelf een ondertekend release-APK bouwen.

## Gebruik

Open TiltFold, kantel je telefoon, klik desgewenst op **Huidige stand = vlak**, stel een foto en gevoeligheid in, druk op **Live wallpaper** en bevestig de systeemdialoog.

## Beperkingen

Deze app rendert alleen het eigen voorbeeld en de Android-achtergrond. Android laat een gewone live wallpaper niet het beeld van willekeurige andere apps vervormen of de home-iconen meevouwen. Voor een volledig schermbrede overlay zijn extra machtigingen en vaak Shizuku/ADB nodig. De sensor wordt gebruikt zolang de preview zichtbaar is of de live wallpaper op het scherm staat. De achtergrond kan batterij kosten; rendering is gemaximeerd op circa 30 fps. Bij een schermrotatie wordt de huidige neutrale kanteling niet automatisch opnieuw bepaald. De code is nog niet op een fysiek Android-toestel getest.

## Gebruikte Android-API's

`WallpaperService`, `SensorManager`, `Canvas.drawBitmapMesh`, `ACTION_OPEN_DOCUMENT`. Minimaal Android 8.0 (API 26). Nul externe Java/Kotlin-dependencies.

# Privacy
TiltFold Lid 1.4 runs on device, uses only motion sensors and a user-chosen document image URI. The manifest declares no requested permissions, Internet access, accessibility services, screen recording or overlay. The effect is restricted to the app preview and live wallpaper.

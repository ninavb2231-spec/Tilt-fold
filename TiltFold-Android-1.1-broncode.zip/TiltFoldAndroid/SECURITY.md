# Veiligheidscontrole

## Statische broncodecheck

Het manifest bevat geen `<uses-permission>`. De app gebruikt uitsluitend openbare Android APIs voor sensoren, tekenen en live wallpaper. Er is geen code voor internetverbindingen, AccessibilityService, SYSTEM_ALERT_WINDOW, MediaProjection, screenshot-, betaal- of administratieve toegang. Een gekozen afbeelding wordt lokaal geladen.

## Waar je zelf op let bij de APK

1. Installeer alleen een APK die **uit dit project** is gebouwd.
2. Vergelijk in de Android-toestemmingslijst dat de app geen toegankelijkheids-, overlay- of schermopnametoestemming vraagt.
3. Laat Play Protect aan.
4. Alleen een broncode-inspectie is geen malware-audit van een later door iemand anders gepubliceerde APK. Een build op je eigen GitHub-workflow levert een controleerbare herkomst.
5. De debug-APK is voor privégebruik en testen; voor distributie is een consistente release-handtekening gewenst.

## Beperkingen

De app is broncode-geïnspecteerd, maar niet met Android Studio gecompileerd of op een fysieke telefoon getest in de aangeleverde omgeving.

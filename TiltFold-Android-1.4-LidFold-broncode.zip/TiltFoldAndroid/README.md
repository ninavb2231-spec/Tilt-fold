# TiltFold Lid 1.4 · iFold-style

Original Android interpretation inspired by [iFold Mac](https://github.com/maheshj01/ifold-mac): a flexing wallpaper sheet with perspective, curvature, directional motion softness, and frost that grows with tilt.

- Real 2D mesh deformation with a simulated bottom hinge; **no middle line**.
- Under-damped spring; continuous gradient shade and wide moving sheen.
- Variable frost blur (light tilt = subtle, high tilt = stronger).
- 3D depth slider, frost slider, sensitivity, reverse direction.
- Tilt left/right by default; optional front/back 'laptop tilt' with re-calibration.
- Only the live wallpaper is affected, **not app icons or other apps**.
- No Internet, Accessibility, Shizuku, screen recording or Restricted Settings.
- This is not the Mac app port, and the source/project are independent. iFold Mac is MIT-licensed; this project uses no copied source.

## GitHub Actions build on mobile
1. Upload the unchanged `TiltFold-Android-1.4-LidFold-broncode.zip` at the root of your GitHub repo.
2. Replace `.github/workflows/build-apk.yml` in GitHub with `TiltFold-Lid-1.4-build-apk.yml` (separate file in ChatGPT).
3. Commit, Actions > `Bouw TiltFold Lid 1.4 APK` > Run workflow.
4. Download `TiltFold-LID-1.4-APK` artifact; unzip, install `TiltFold-LID-1.4.apk`.

Android applicationId `nl.tiltfold.lidfold` is distinct from 1.2/1.3 and can live alongside those versions. Debug builds may get distinct signatures across GitHub runners; no need to uninstall older versions.

Built in Android Studio / Gradle 8.9 and Android Gradle Plugin 8.7.3. Use only when Android APK verifier succeeds.

Recommended initial settings: sensitivity 100%, frost 80%, 3D depth 75%. For laptop-style front/back tilt switch axis and calibrate with phone held at its neutral position.

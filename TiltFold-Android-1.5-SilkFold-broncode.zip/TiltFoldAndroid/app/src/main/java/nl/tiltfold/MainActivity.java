package nl.tiltfold;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 431;
    private FoldPreview preview;
    private LinearLayout settingsPanel;
    private Button exitFullscreen;
    private boolean fullscreen;
    private TextView status;
    private TextView strengthValue;
    private TextView glassValue;
    private TextView depthValue;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(6, 10, 22));
        getWindow().setNavigationBarColor(Color.rgb(6, 10, 22));
        // De app houdt het scherm niet onnodig aan.

        FrameLayout root = new FrameLayout(this);
        root.setFitsSystemWindows(true);
        preview = new FoldPreview();
        root.addView(preview, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout panel = new LinearLayout(this);
        settingsPanel = panel;
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(22), dp(22), dp(22), dp(24));
        GradientDrawable card = new GradientDrawable();
        card.setColor(0xE5101829);
        card.setCornerRadius(dp(28));
        card.setStroke(dp(1), 0x443DE2DB);
        panel.setBackground(card);
        FrameLayout.LayoutParams panelLp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        panelLp.setMargins(dp(16), dp(16), dp(16), dp(20));
        root.addView(panel, panelLp);

        TextView eyebrow = label("T I L T F O L D   •   1.5 / S I L K", 12, 0xFF63E5DB, true);
        panel.addView(eyebrow);
        TextView title = label("SilkFold · iFold Style", 23, Color.WHITE, true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(9);
        panel.addView(title, titleLp);
        status = label("Een flexibele glasplaat die wegkrult, schaduwt en vervaagt.",
                14, 0xFFC5CDDB, false);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2);
        statusLp.topMargin = dp(8);
        statusLp.bottomMargin = dp(19);
        panel.addView(status, statusLp);

        TextView sensitivityLabel = label("Gevoeligheid", 14, 0xFFE3E8F0, true);
        panel.addView(sensitivityLabel);
        LinearLayout sensitivityRow = new LinearLayout(this);
        sensitivityRow.setGravity(Gravity.CENTER_VERTICAL);
        SeekBar slider = new SeekBar(this);
        slider.setMax(180);
        slider.setProgress(getSharedPreferences(FoldRenderer.PREFS, 0)
                .getInt(FoldRenderer.STRENGTH, 100) - 20);
        slider.setProgressTintList(ColorStateList.valueOf(0xFF58E3D2));
        slider.setThumbTintList(ColorStateList.valueOf(0xFF9FFFF4));
        sensitivityRow.addView(slider, new LinearLayout.LayoutParams(0, dp(45), 1));
        strengthValue = label("100%", 13, Color.WHITE, true);
        sensitivityRow.addView(strengthValue);
        panel.addView(sensitivityRow);
        updateStrength(slider.getProgress() + 20, false);
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                updateStrength(progress + 20, fromUser);
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });

        // Frosted glass opacity is stored locally and used by the live wallpaper too.
        TextView glassLabel = label("Melkglas bij kantelen", 14, 0xFFE3E8F0, true);
        LinearLayout.LayoutParams glassLabelLp = new LinearLayout.LayoutParams(-1, -2);
        glassLabelLp.topMargin = dp(4);
        panel.addView(glassLabel, glassLabelLp);
        LinearLayout glassRow = new LinearLayout(this);
        glassRow.setGravity(Gravity.CENTER_VERTICAL);
        SeekBar frostSlider = new SeekBar(this);
        frostSlider.setMax(100);
        frostSlider.setProgress(getSharedPreferences(FoldRenderer.PREFS, 0)
                .getInt(FoldRenderer.GLASS, 85));
        frostSlider.setProgressTintList(ColorStateList.valueOf(0xFFB9B4FF));
        frostSlider.setThumbTintList(ColorStateList.valueOf(0xFFE1DEFF));
        glassRow.addView(frostSlider, new LinearLayout.LayoutParams(0, dp(43), 1));
        glassValue = label(frostSlider.getProgress() + "%", 13, Color.WHITE, true);
        glassRow.addView(glassValue);
        panel.addView(glassRow);
        frostSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                glassValue.setText(progress + "%");
                if (fromUser) getSharedPreferences(FoldRenderer.PREFS, 0).edit()
                        .putInt(FoldRenderer.GLASS, progress).apply();
                preview.invalidate();
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });

        TextView depthLabel = label("3D-boog & perspectief", 14, 0xFFE3E8F0, true);
        LinearLayout.LayoutParams depthLabelLp = new LinearLayout.LayoutParams(-1, -2);
        depthLabelLp.topMargin = dp(4);
        panel.addView(depthLabel, depthLabelLp);
        LinearLayout depthRow = new LinearLayout(this);
        depthRow.setGravity(Gravity.CENTER_VERTICAL);
        SeekBar depthSlider = new SeekBar(this);
        depthSlider.setMax(100);
        depthSlider.setProgress(getSharedPreferences(FoldRenderer.PREFS, 0).getInt(FoldRenderer.DEPTH, 78));
        depthSlider.setProgressTintList(ColorStateList.valueOf(0xFFB9B4FF));
        depthSlider.setThumbTintList(ColorStateList.valueOf(0xFFE1DEFF));
        depthRow.addView(depthSlider, new LinearLayout.LayoutParams(0, dp(41), 1));
        depthValue = label(depthSlider.getProgress() + "%", 13, Color.WHITE, true);
        depthRow.addView(depthValue);
        panel.addView(depthRow);
        depthSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                depthValue.setText(progress + "%");
                if (fromUser) getSharedPreferences(FoldRenderer.PREFS, 0).edit()
                        .putInt(FoldRenderer.DEPTH, progress).apply();
                preview.invalidate();
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });

        Switch pitchMode = new Switch(this);
        pitchMode.setText("Laptopkanteling (voor-/achterover)");
        pitchMode.setTextColor(0xFFE5F8F7);
        pitchMode.setTextSize(13);
        pitchMode.setChecked(getSharedPreferences(FoldRenderer.PREFS, 0)
                .getBoolean(TiltTracker.PITCH_MODE, false));
        pitchMode.setOnCheckedChangeListener((buttonView, isChecked) -> {
            getSharedPreferences(FoldRenderer.PREFS, 0).edit()
                    .putBoolean(TiltTracker.PITCH_MODE, isChecked).apply();
            preview.resetAxis();
            Toast.makeText(this, "Nieuwe kantelrichting: kalibreer je vlakke stand", Toast.LENGTH_SHORT).show();
        });
        panel.addView(pitchMode);

        Switch reverse = new Switch(this);
        reverse.setText("Kantelrichting omkeren");
        reverse.setTextColor(0xFFE5F8F7);
        reverse.setTextSize(13);
        reverse.setChecked(getSharedPreferences(FoldRenderer.PREFS, 0)
                .getBoolean(FoldRenderer.REVERSED, false));
        reverse.setOnCheckedChangeListener((buttonView, isChecked) -> {
            getSharedPreferences(FoldRenderer.PREFS, 0).edit()
                    .putBoolean(FoldRenderer.REVERSED, isChecked).apply();
            preview.invalidate();
        });
        panel.addView(reverse);

        LinearLayout buttons = new LinearLayout(this);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
        rowLp.topMargin = dp(10);
        panel.addView(buttons, rowLp);

        Button choose = button("Kies foto", 0xFF27394B, Color.WHITE);
        LinearLayout.LayoutParams chooseLp = new LinearLayout.LayoutParams(0, dp(52), 1);
        chooseLp.rightMargin = dp(8);
        buttons.addView(choose, chooseLp);
        choose.setOnClickListener(v -> pickPhoto());

        Button apply = button("Live wallpaper", 0xFF5BE3D4, 0xFF10212B);
        buttons.addView(apply, new LinearLayout.LayoutParams(0, dp(52), 1.3f));
        apply.setOnClickListener(v -> applyWallpaper());

        Button calibrate = button("◎  Huidige stand = vlak", 0xFF18283A, 0xFFE8FBF7);
        LinearLayout.LayoutParams calibrateLp = new LinearLayout.LayoutParams(-1, dp(48));
        calibrateLp.topMargin = dp(9);
        panel.addView(calibrate, calibrateLp);
        calibrate.setOnClickListener(v -> {
            preview.calibrate();
            Toast.makeText(this, "Neutrale stand opgeslagen voor preview én achtergrond", Toast.LENGTH_SHORT).show();
        });

        Button reset = button("Standaardachtergrond herstellen", 0xFF18283A, 0xFFB9D8E1);
        LinearLayout.LayoutParams resetLp = new LinearLayout.LayoutParams(-1, dp(43));
        resetLp.topMargin = dp(8);
        panel.addView(reset, resetLp);
        reset.setOnClickListener(v -> {
            getSharedPreferences(FoldRenderer.PREFS, 0).edit()
                    .remove(FoldRenderer.IMAGE).apply();
            preview.refreshArtwork();
            Toast.makeText(this, "Standaardachtergrond hersteld", Toast.LENGTH_SHORT).show();
        });

        Button fullscreenButton = button("⛶  Bekijk animatie op volledig scherm", 0xFF36455D, Color.WHITE);
        LinearLayout.LayoutParams fullLp = new LinearLayout.LayoutParams(-1, dp(48));
        fullLp.topMargin = dp(10);
        panel.addView(fullscreenButton, fullLp);
        fullscreenButton.setOnClickListener(v -> setFullscreen(true));

        exitFullscreen = button("✕  Terug naar instellingen", 0xE5142034, Color.WHITE);
        FrameLayout.LayoutParams exitLp = new FrameLayout.LayoutParams(-2, dp(48), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        exitLp.topMargin = dp(20);
        root.addView(exitFullscreen, exitLp);
        exitFullscreen.setVisibility(View.GONE);
        exitFullscreen.setOnClickListener(v -> setFullscreen(false));

        TextView note = label("Eén 3D-gebogen vlak met bewegingsonscherpte, zachte reflecties en progressieve frost. Alleen de achtergrond verandert.",
                12, 0xFF8FA8B8, false);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.topMargin = dp(14);
        panel.addView(note, noteLp);
        setContentView(root);
        if (!preview.hasSensor()) status.setText("Geen bewegingssensor gevonden op dit apparaat.");
    }

    private TextView label(String text, int sp, int color, boolean bold) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(sp);
        label.setTextColor(color);
        if (bold) label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return label;
    }

    private Button button(String text, int fill, int textColor) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(textColor);
        b.setTextSize(13);
        b.setAllCaps(false);
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(fill);
        shape.setCornerRadius(dp(14));
        b.setBackground(shape);
        return b;
    }

    private int dp(float d) { return (int) (d * getResources().getDisplayMetrics().density + .5f); }

    private void updateStrength(int value, boolean save) {
        strengthValue.setText(value + "%");
        if (save) getSharedPreferences(FoldRenderer.PREFS, 0).edit()
                .putInt(FoldRenderer.STRENGTH, value).apply();
        preview.invalidate();
    }

    private void pickPhoto() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_IMAGE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try { getContentResolver().takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (SecurityException ignored) {}
            getSharedPreferences(FoldRenderer.PREFS, 0).edit()
                    .putString(FoldRenderer.IMAGE, uri.toString()).apply();
            preview.refreshArtwork();
            Toast.makeText(this, "Foto ingesteld", Toast.LENGTH_SHORT).show();
        }
    }

    private void applyWallpaper() {
        Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
        intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                new ComponentName(this, FoldWallpaperService.class));
        try { startActivity(intent); }
        catch (Exception e) {
            Toast.makeText(this, "Open je achtergrondinstellingen en kies TiltFold", Toast.LENGTH_LONG).show();
        }
    }

    private void setFullscreen(boolean enabled) {
        fullscreen = enabled;
        settingsPanel.setVisibility(enabled ? View.GONE : View.VISIBLE);
        exitFullscreen.setVisibility(enabled ? View.VISIBLE : View.GONE);
        preview.invalidate();
    }

    @Override public void onBackPressed() {
        if (fullscreen) setFullscreen(false);
        else super.onBackPressed();
    }

    @Override protected void onResume() { super.onResume(); if (preview != null) preview.start(); }
    @Override protected void onPause() { if (preview != null) preview.stop(); super.onPause(); }

    private final class FoldPreview extends View {
        private final FoldRenderer renderer = new FoldRenderer(MainActivity.this);
        private final TiltTracker tracker;
        private final TiltAnimator animator = new TiltAnimator();
        private boolean active;
        FoldPreview() {
            super(MainActivity.this);
            tracker = new TiltTracker(MainActivity.this, this::onTiltUpdate);
            // Keep the default hardware-accelerated preview when available.
        }
        private void onTiltUpdate() {
            if (active) postInvalidateOnAnimation();
            if (status != null) {
                float angle = tracker.getDegrees();
                String direction = angle >= 0 ? "rechts" : "links";
                status.setText(String.format(java.util.Locale.forLanguageTag("nl-NL"),
                        "Kanteling: %.0f° %s", Math.abs(angle), direction));
            }
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            boolean moving = animator.step(tracker.getDegrees());
            renderer.draw(canvas, animator.getDegrees(), animator.getVelocity());
            if (active && moving) postInvalidateOnAnimation();
        }
        boolean hasSensor() { return tracker.hasSensor(); }
        void start() {
            active = true;
            animator.snapTo(tracker.getDegrees());
            tracker.start();
            invalidate();
        }
        void stop() { active = false; tracker.stop(); }
        void calibrate() { tracker.calibrate(); animator.snapTo(0f); invalidate(); }
        void resetAxis() { tracker.reloadCalibration(); animator.snapTo(0f); invalidate(); }
        void refreshArtwork() { renderer.invalidateArtwork(); invalidate(); }
    }
}

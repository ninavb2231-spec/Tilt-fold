# Privacy

TiltFold Frost 1.3 verwerkt het bewegingssignaal lokaal en leest uitsluitend de achtergrondafbeelding die je kiest. De afbeelding wordt lokaal bewaard via Androids persistente lees-URI. Er is geen internetpermissie, toegankelijkheidsservice, schermopname of Shizuku. De app doet geen telemetrie en vraagt geen Restricted settings. Het is een live wallpaper en verandert geen inhoud van andere apps.

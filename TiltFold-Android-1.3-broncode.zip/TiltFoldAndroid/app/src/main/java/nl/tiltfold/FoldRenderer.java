package nl.tiltfold;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ComposeShader;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.net.Uri;

import java.io.InputStream;
import java.util.Random;

/**
 * TiltFold 1.3: continuous Liquid Glass blur. The source photo is never split into panels.
 * Three blurred mip levels are cached and blended through a smooth alpha mask.
 * No hard hinge, seam, rim, clipping line or accessibility permission.
 */
final class FoldRenderer {
    static final String PREFS = "tiltfold";
    static final String IMAGE = "image";
    static final String STRENGTH = "strength";
    static final String REVERSED = "reversed";
    static final String GLASS = "glass_level";

    private final Context context;
    private final Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint glassPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final int[] maskColors = new int[13];
    private final float[] maskPositions = new float[13];
    private Bitmap scene, blurSoft, blurMedium, blurStrong, noise;
    private BitmapShader softShader, mediumShader, strongShader, noiseShader;
    private int width, height;
    private String lastUri;

    FoldRenderer(Context context) {
        this.context = context.getApplicationContext();
        for (int i = 0; i < maskPositions.length; i++) {
            maskPositions[i] = i / 12f;
        }
    }

    void invalidateArtwork() {
        recycle(scene);
        recycle(blurSoft);
        recycle(blurMedium);
        recycle(blurStrong);
        scene = blurSoft = blurMedium = blurStrong = null;
        softShader = mediumShader = strongShader = null;
    }

    private static void recycle(Bitmap bmp) {
        if (bmp != null && !bmp.isRecycled()) bmp.recycle();
    }

    private static float clamp(float x) { return Math.max(0f, Math.min(1f, x)); }
    private static float smooth(float x) { x = clamp(x); return x * x * (3f - 2f * x); }

    private static int white(float a) {
        return (Math.round(clamp(a) * 255f) << 24) | 0x00FFFFFF;
    }

    void draw(Canvas canvas, float tiltDegrees) {
        int w = canvas.getWidth();
        int h = canvas.getHeight();
        ensureBitmaps(w, h);
        if (scene == null) return;

        android.content.SharedPreferences prefs = context.getSharedPreferences(PREFS, 0);
        if (prefs.getBoolean(REVERSED, false)) tiltDegrees = -tiltDegrees;
        float sensitivity = prefs.getInt(STRENGTH, 100) / 100f;
        float frost = clamp(prefs.getInt(GLASS, 82) / 100f);
        float amount = smooth(Math.abs(tiltDegrees) * sensitivity / 49f);
        boolean toRight = tiltDegrees >= 0;

        // A single continuous canvas: no panel edges, no line down the middle.
        imagePaint.setShader(null);
        imagePaint.setAlpha(255);
        canvas.drawBitmap(scene, 0f, 0f, imagePaint);
        if (amount <= .001f || frost < .001f) return;

        // Smooth mask spans almost the entire screen. Frost is strongest toward
        // the tilted side but also fades gently across the opposite half.
        for (int i = 0; i < maskColors.length; i++) {
            float x = i / 12f;
            if (!toRight) x = 1f - x;
            float gradient = smooth((x - .06f) / .87f);
            float coverage = (.12f + .88f * gradient);
            maskColors[i] = white(coverage);
        }
        Shader fade = new LinearGradient(0, 0, w, 0,
                maskColors, maskPositions, Shader.TileMode.CLAMP);

        // More tilt produces greater opacity AND moves through progressively
        // stronger pre-blurred textures. This makes blur strength truly dynamic.
        float mild = frost * smooth(amount * 3f);
        float medium = frost * smooth((amount - .14f) / .69f);
        float heavy = frost * smooth((amount - .43f) / .52f);
        drawFrost(canvas, softShader, fade, mild, w, h);
        drawFrost(canvas, mediumShader, fade, medium, w, h);
        drawFrost(canvas, strongShader, fade, heavy, w, h);

        // A continuous translucent cool-white diffusion veil, no sharp stroke.
        float mist = frost * amount;
        glassPaint.setAlpha(255);
        glassPaint.setShader(new LinearGradient(0f, h * .18f, w, h * .78f,
                toRight ? new int[]{white(.018f * mist), white(.058f * mist), white(.23f * mist)}
                        : new int[]{white(.23f * mist), white(.058f * mist), white(.018f * mist)},
                new float[]{0f, .52f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, glassPaint);
        glassPaint.setShader(null);

        // Broad travelling reflection, shaped like light scattering in satin glass.
        float center = w * (.50f + (toRight ? 1f : -1f) * .20f * amount);
        float radius = w * (.25f + .14f * amount);
        float a = .16f * mist;
        glassPaint.setShader(new LinearGradient(center - radius, h * .8f,
                center + radius, h * .14f,
                new int[]{white(0), white(a * .38f), white(a), white(a * .30f), white(0)},
                new float[]{0f, .30f, .51f, .72f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, glassPaint);
        glassPaint.setShader(null);

        // Almost imperceptible micrograin keeps blurred gradients from looking plastic.
        if (amount > .10f) {
            ensureNoise();
            glassPaint.setShader(noiseShader);
            glassPaint.setAlpha(Math.min(255, Math.round(105f * frost * amount)));
            canvas.drawRect(0, 0, w, h, glassPaint);
            glassPaint.setShader(null);
            glassPaint.setAlpha(255);
        }
    }

    /** Compose the blurred image and its alpha gradient in one pass, no offscreen layer. */
    private void drawFrost(Canvas canvas, BitmapShader bitmap, Shader fade, float alpha,
                           int w, int h) {
        if (bitmap == null || alpha <= .005f) return;
        imagePaint.setShader(new ComposeShader(bitmap, fade, PorterDuff.Mode.DST_IN));
        imagePaint.setAlpha(Math.round(clamp(alpha) * 255f));
        canvas.drawRect(0f, 0f, w, h, imagePaint);
        imagePaint.setShader(null);
        imagePaint.setAlpha(255);
    }

    private void ensureBitmaps(int w, int h) {
        if (w < 2 || h < 2) return;
        String uri = context.getSharedPreferences(PREFS, 0).getString(IMAGE, "");
        if (uri == null) uri = "";
        if (scene != null && w == width && h == height && uri.equals(lastUri)) return;
        invalidateArtwork();
        width = w;
        height = h;
        lastUri = uri;
        scene = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(scene);
        drawDefaultBackground(c, w, h);
        if (!uri.isEmpty()) {
            try (InputStream input = context.getContentResolver().openInputStream(Uri.parse(uri))) {
                if (input != null) {
                    BitmapFactory.Options bounds = new BitmapFactory.Options();
                    bounds.inJustDecodeBounds = true;
                    try (InputStream boundStream = context.getContentResolver()
                            .openInputStream(Uri.parse(uri))) {
                        if (boundStream != null) BitmapFactory.decodeStream(boundStream, null, bounds);
                    }
                    int sample = 1;
                    while (bounds.outWidth > 0 && bounds.outHeight > 0 &&
                            (bounds.outWidth / sample > w * 2 || bounds.outHeight / sample > h * 2)) {
                        sample *= 2;
                    }
                    BitmapFactory.Options actual = new BitmapFactory.Options();
                    actual.inSampleSize = sample;
                    Bitmap photo = BitmapFactory.decodeStream(input, null, actual);
                    if (photo != null) {
                        float scale = Math.max(w / (float) photo.getWidth(), h / (float) photo.getHeight());
                        float dw = photo.getWidth() * scale;
                        float dh = photo.getHeight() * scale;
                        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                        c.drawBitmap(photo, null, new RectF((w - dw) / 2, (h - dh) / 2,
                                (w + dw) / 2, (h + dh) / 2), p);
                        photo.recycle();
                    }
                }
            } catch (Exception ignored) { /* Keep built-in scene when an image is unavailable. */ }
        }
        blurSoft = blurry(scene, 12);
        blurMedium = blurry(scene, 27);
        blurStrong = blurry(scene, 58);
        softShader = new BitmapShader(blurSoft, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        mediumShader = new BitmapShader(blurMedium, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        strongShader = new BitmapShader(blurStrong, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
    }

    /** Pre-render blur textures once per artwork change, never inside a frame. */
    private static Bitmap blurry(Bitmap original, int factor) {
        int w = original.getWidth(), h = original.getHeight();
        Bitmap tiny = Bitmap.createScaledBitmap(original, Math.max(1, w / factor),
                Math.max(1, h / factor), true);
        Bitmap intermediate = Bitmap.createScaledBitmap(tiny, Math.max(1, w / 5),
                Math.max(1, h / 5), true);
        Bitmap soft = Bitmap.createScaledBitmap(intermediate, w, h, true);
        if (tiny != original && tiny != soft) tiny.recycle();
        if (intermediate != original && intermediate != soft) intermediate.recycle();
        return soft;
    }

    private void ensureNoise() {
        if (noise != null && !noise.isRecycled()) return;
        Random random = new Random(41012);
        int size = 96;
        int[] pixels = new int[size * size];
        for (int i = 0; i < pixels.length; i++) {
            pixels[i] = (random.nextBoolean() ? 0x0FFFFFFF : 0x0A000000);
        }
        noise = Bitmap.createBitmap(pixels, size, size, Bitmap.Config.ARGB_8888);
        noiseShader = new BitmapShader(noise, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
    }

    private static void drawDefaultBackground(Canvas c, int w, int h) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, w, h,
                new int[]{0xFF06131D, 0xFF113B64, 0xFF4E2D79, 0xFF140C27},
                new float[]{0f, .34f, .69f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(new RadialGradient(.18f * w, .30f * h, .72f * w,
                new int[]{0xD92FEEDE, 0x0059A0FF}, null, Shader.TileMode.CLAMP));
        c.drawCircle(.18f * w, .30f * h, .72f * w, p);
        p.setShader(new RadialGradient(.89f * w, .73f * h, .83f * w,
                new int[]{0xBDEE5AC4, 0x00F95799}, null, Shader.TileMode.CLAMP));
        c.drawCircle(.89f * w, .73f * h, .83f * w, p);
        Random random = new Random(4101);
        p.setShader(null);
        for (int i = 0; i < 110; i++) {
            p.setColor(0x66FFFFFF);
            c.drawCircle(random.nextFloat() * w, random.nextFloat() * h,
                    .5f + random.nextFloat() * 1.9f, p);
        }
        p.setColor(0x33FFFFFF);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(w * .0023f);
        for (int i = 1; i <= 4; i++) {
            float radius = w * (.24f + .17f * i);
            c.drawCircle(w * .52f, h * .50f, radius, p);
        }
        p.setStyle(Paint.Style.FILL);
    }
}

# Security
A separate applicationId is used so older versions remain available. GitHub Actions verifies version and APK signature before uploading an artifact. A successful build is not a malware audit; inspect sources and APK with your own tools.

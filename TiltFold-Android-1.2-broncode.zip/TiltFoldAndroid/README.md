# TiltFold 1.2: Liquid Glass Edition

Een volledig offline Android-live-wallpaper met een kantelgestuurd vouw-effect. Deze versie bouwt voort op de werkende TiltFold 1.1, met een mooiere matglaslaag en een vloeiendere animatie.

## Wat is nieuw?

- Echte, transparante *frosted glass*-illusie: de geblurde achtergrond blijft zichtbaar onder de bewegende, halfdoorzichtige glaslaag.
- Instelbare schuifregelaar **Melkglas & reflectie** (0-100%).
- Meebewegende zachte lichtreflecties, subtiele glastextuur, heldere glasranden en een dieper scharnier.
- Een kritisch gedempte animatie, die tussen de sensormetingen door wordt berekend. Maximaal ~60 frames per seconde in plaats van 30, zolang het scherm beweegt.
- De animatie pauzeert zodra de beweging tot stilstand komt, om stroom te besparen.
- Behoud van eigen foto, gevoeligheid, omgekeerde kantelrichting en gedeelde kalibratie.

Dit is een **live wallpaper**. De achtergrond kan virtueel vouwen, maar app-pictogrammen en de inhoud van andere apps worden niet vervormd. Daarvoor zouden extra systeemrechten of schermopname nodig zijn. TiltFold vraagt die niet aan.

## Veiligheid

Geen internet, accounts, analytics, reclame, tracking, Shizuku, toegankelijkheidsservice, schermopname of *Restricted settings* nodig. Het manifest vraagt geen applicatierechten aan. De Android-bestandskiezer verleent uitsluitend toegang tot een foto die de gebruiker zelf kiest. Alles draait op de telefoon.

## Bouwen in de bestaande GitHub-repository van de gebruiker

De gebruiker heeft al een werkende GitHub Actions-workflow met een ZIP in de repository. Dit is de eenvoudigste update:

1. Download de nieuwe `TiltFold-Android-1.2-broncode.zip` **zonder uitpakken**.
2. Open in GitHub de repository `ninavb2231-spec/Tilt-fold`, tab **Code** > **Add file** > **Upload files**, selecteer de ZIP en commit.
3. Open `.github/workflows/build-apk.yml` in GitHub en kies **Edit**.
4. Vervang alleen `TiltFold-Android-1.1-broncode.zip` door `TiltFold-Android-1.2-broncode.zip` in de `unzip`-regel.
5. Commit. Ga naar **Actions** > **Bouw TiltFold APK** > **Run workflow**. Download onder **Artifacts** het nieuwe `TiltFold-APK` en pak de gedownloade artifact-ZIP uit.
6. Installeer `app-debug.apk`. Let op: GitHub genereert per build gewoonlijk een nieuwe *debug*-signing key. Als Android 'App niet geïnstalleerd' meldt, verwijder dan eerst de oude TiltFold-versie. Hierdoor kunnen de oude app-instellingen verdwijnen; kies dan opnieuw je foto en kalibreer opnieuw.

**Let op:** de workflow moet al `packages: platform-tools` hebben bij `android-actions/setup-android@v3`. Dat was de oplossing voor de eerdere SDK-fout. De broncode-ZIP bevat tevens een complete workflow voor gebruikers die vanaf nul beginnen, maar bij een repository met één ZIP moet de bovenstaande bestaande workflow worden gebruikt.

De ZIP bevat een bovenliggende projectmap `TiltFoldAndroid`. De build-opdracht in de bestaande workflow blijft `gradle -p TiltFoldAndroid :app:assembleDebug --no-daemon`.

## Direct in Android Studio

Open de projectmap `TiltFoldAndroid`. Android Studio: AGP 8.7.3, Java 17, compileSdk 35 en Gradle 8.9. Start de debug-build met `gradle :app:assembleDebug` of **Build > Build APK(s)**.

## Bestanden

- `app/src/main/java/nl/tiltfold/FoldRenderer.java` implementeert het matte glas en de beeldvervorming.
- `app/src/main/java/nl/tiltfold/TiltAnimator.java` berekent de vloeiende tussenframes.
- `app/src/main/java/nl/tiltfold/TiltTracker.java` verwerkt sensorsignalen.
- `app/src/main/java/nl/tiltfold/FoldWallpaperService.java` toont de wallpaper.
- `app/src/main/java/nl/tiltfold/MainActivity.java` bevat voorbeeldscherm en instellingen.
- `SECURITY.md` en `PRIVACY.md` lichten toestemmingen en privacy toe.

Android 8 of nieuwer; ontwikkeld voor een staande telefoon. Java/XML-syntaxis gecontroleerd; de APK is niet in deze omgeving gebouwd en de versie is nog niet op een fysieke telefoon getest.

package nl.tiltfold;

import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

public final class FoldWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new FoldEngine(); }

    private final class FoldEngine extends Engine implements SharedPreferences.OnSharedPreferenceChangeListener {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final FoldRenderer renderer = new FoldRenderer(FoldWallpaperService.this);
        private final TiltTracker tracker = new TiltTracker(FoldWallpaperService.this, this::scheduleFrame);
        private final SharedPreferences preferences = getSharedPreferences(FoldRenderer.PREFS, 0);
        private boolean visible;
        private boolean framePending;
        private final Runnable drawTask = () -> {
            framePending = false;
            render();
        };

        FoldEngine() {
            preferences.registerOnSharedPreferenceChangeListener(this);
            setTouchEventsEnabled(false);
        }

        private void scheduleFrame() {
            if (!visible || framePending) return;
            framePending = true;
            handler.postDelayed(drawTask, 33); // Maximum around 30 fps while moving.
        }

        private void render() {
            if (!visible) return;
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas != null) renderer.draw(canvas, tracker.getDegrees());
            } catch (Exception ignored) {
                // Surface may disappear while the wallpaper is switching.
            } finally {
                if (canvas != null) {
                    try { holder.unlockCanvasAndPost(canvas); } catch (Exception ignored) {}
                }
            }
        }

        @Override public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            handler.removeCallbacks(drawTask);
            framePending = false;
            if (visible) {
                renderer.invalidateArtwork();
                tracker.start();
                render();
            } else tracker.stop();
        }

        @Override public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            renderer.invalidateArtwork();
            scheduleFrame();
        }

        @Override public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {
            if (FoldRenderer.IMAGE.equals(key)) renderer.invalidateArtwork();
            if (TiltTracker.CALIBRATION.equals(key)) tracker.reloadCalibration();
            scheduleFrame();
        }

        @Override public void onDestroy() {
            visible = false;
            handler.removeCallbacks(drawTask);
            tracker.stop();
            renderer.invalidateArtwork();
            preferences.unregisterOnSharedPreferenceChangeListener(this);
            super.onDestroy();
        }
    }
}

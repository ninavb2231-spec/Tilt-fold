package nl.tiltfold;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.net.Uri;

import java.io.InputStream;
import java.util.Random;

/** A permission-free 2D hinged-glass illusion; all blur textures are cached per image. */
final class FoldRenderer {
    static final String PREFS = "tiltfold";
    static final String IMAGE = "image";
    static final String STRENGTH = "strength";
    static final String REVERSED = "reversed";
    static final String GLASS = "glass_level";

    private final Context context;
    private final Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint glassPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Path panelShape = new Path();
    private final float[] mesh = new float[21 * 21 * 2];
    private Bitmap scene, left, right, blurLeft, blurRight;
    private Bitmap noise;
    private BitmapShader noiseShader;
    private int width, height;
    private String lastUri;

    FoldRenderer(Context context) { this.context = context.getApplicationContext(); }

    void invalidateArtwork() {
        recycle(scene);
        recycle(left);
        recycle(right);
        recycle(blurLeft);
        recycle(blurRight);
        scene = left = right = blurLeft = blurRight = null;
    }

    private static void recycle(Bitmap bmp) {
        if (bmp != null && !bmp.isRecycled()) bmp.recycle();
    }

    void draw(Canvas canvas, float tiltDegrees) {
        int w = canvas.getWidth();
        int h = canvas.getHeight();
        ensureBitmaps(w, h);
        if (scene == null) return;
        if (context.getSharedPreferences(PREFS, 0).getBoolean(REVERSED, false)) {
            tiltDegrees = -tiltDegrees;
        }
        float sensitivity = context.getSharedPreferences(PREFS, 0).getInt(STRENGTH, 100) / 100f;
        float frost = Math.max(0, Math.min(1f,
                context.getSharedPreferences(PREFS, 0).getInt(GLASS, 75) / 100f));
        float n = Math.min(1f, Math.abs(tiltDegrees) * sensitivity / 48f);

        canvas.drawColor(0xFF090B18);
        if (n < .0025f) {
            imagePaint.setAlpha(255);
            canvas.drawBitmap(scene, 0f, 0f, imagePaint);
            return;
        }

        boolean rightSide = tiltDegrees >= 0f;
        float middle = w / 2f;
        // The stationary panel remains sharp, with the original image precisely aligned.
        canvas.save();
        if (rightSide) canvas.clipRect(0, 0, middle, h);
        else canvas.clipRect(middle, 0, w, h);
        imagePaint.setAlpha(255);
        canvas.drawBitmap(scene, 0f, 0f, imagePaint);
        canvas.restore();

        float angle = (float) Math.toRadians(78f * ease(n));
        float cos = (float) Math.cos(angle);
        float extent = (middle * cos) / (1 + .43f * n);
        float edge = rightSide ? middle + extent : middle - extent;
        float shrink = .083f * n;
        setMesh(middle, h, rightSide, cos, n);

        Bitmap crisp = rightSide ? right : left;
        Bitmap soft = rightSide ? blurRight : blurLeft;
        imagePaint.setAlpha(255);
        canvas.drawBitmapMesh(crisp, 20, 20, mesh, 0, null, 0, imagePaint);
        if (frost > .005f) {
            // Blurred underlying scene: this is the actual translucent, frosted layer.
            imagePaint.setAlpha(Math.min(225, Math.round(242f * frost * n)));
            canvas.drawBitmapMesh(soft, 20, 20, mesh, 0, null, 0, imagePaint);
            imagePaint.setAlpha(255);
        }

        panelShape.reset();
        panelShape.moveTo(middle, 0);
        panelShape.lineTo(edge, h * shrink);
        panelShape.lineTo(edge, h * (1 - shrink));
        panelShape.lineTo(middle, h);
        panelShape.close();

        canvas.save();
        canvas.clipPath(panelShape);

        // An optically soft white veil, brighter at the leading edge of the moving pane.
        float lit = (.21f + .72f * n) * frost;
        glassPaint.setStyle(Paint.Style.FILL);
        glassPaint.setShader(new LinearGradient(middle, h * .08f, edge, h * .92f,
                new int[]{whiteAlpha(.08f * lit), whiteAlpha(.40f * lit),
                        whiteAlpha(.15f * lit), whiteAlpha(.29f * lit)},
                new float[]{0, .20f, .65f, 1}, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, glassPaint);
        glassPaint.setShader(null);

        // Dark inner edge gives the panel physical thickness and emphasizes the fold.
        glassPaint.setShader(new LinearGradient(middle, 0, edge, 0,
                new int[]{0x30000008, 0x08000013, 0x9B000613},
                new float[]{0, .56f, 1}, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, glassPaint);
        glassPaint.setShader(null);

        // Moving, angled specular streaks. They follow the projection, not the screen edge.
        float dx = edge - middle;
        float highlightX = middle + dx * (.26f + .28f * n);
        float sweep = Math.max(9, Math.abs(dx) * .16f);
        glassPaint.setShader(new LinearGradient(highlightX - sweep, h * .74f,
                highlightX + sweep, h * .21f,
                new int[]{0x00FFFFFF, whiteAlpha(.32f * frost * n),
                        whiteAlpha(.04f * frost * n), 0x00FFFFFF},
                new float[]{0, .38f, .55f, 1}, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, glassPaint);
        glassPaint.setShader(null);

        // A faint texture breaks up flat gradients, like finely etched matte glass.
        if (frost > .01f && n > .035f) {
            ensureNoise();
            glassPaint.setShader(noiseShader);
            glassPaint.setAlpha(Math.min(95, Math.round(80 * frost * n)));
            canvas.drawRect(0, 0, w, h, glassPaint);
            glassPaint.setAlpha(255);
            glassPaint.setShader(null);
        }
        canvas.restore();

        // Reflection on the sharp stationary pane near the hinge.
        float staticX = rightSide ? middle - w * .14f * n : middle + w * .14f * n;
        glassPaint.setShader(new LinearGradient(staticX, 0, middle, 0,
                new int[]{0x00000000, whiteAlpha(.11f * frost * n)},
                null, Shader.TileMode.CLAMP));
        canvas.save();
        if (rightSide) canvas.clipRect(0, 0, middle, h);
        else canvas.clipRect(middle, 0, w, h);
        canvas.drawRect(Math.min(staticX, middle), 0, Math.max(staticX, middle), h, glassPaint);
        canvas.restore();
        glassPaint.setShader(null);

        // Narrow luminous rims, softer and more dimensional than the old hard black seam.
        glassPaint.setStyle(Paint.Style.STROKE);
        glassPaint.setStrokeWidth(Math.max(1.3f, w * .0019f));
        glassPaint.setColor(whiteAlpha((.08f + .48f * n) * frost));
        canvas.drawLine(edge, h * shrink, edge, h * (1 - shrink), glassPaint);
        glassPaint.setStrokeWidth(Math.max(1.4f, w * .0028f));
        glassPaint.setColor(whiteAlpha((.09f + .27f * n) * frost));
        canvas.drawLine(middle + (rightSide ? 1 : -1), 0,
                middle + (rightSide ? 1 : -1), h, glassPaint);
        glassPaint.setStyle(Paint.Style.FILL);
        glassPaint.setColor(Color.WHITE);
    }

    private static int whiteAlpha(float alpha) {
        return (Math.min(255, Math.max(0, Math.round(alpha * 255))) << 24) | 0x00FFFFFF;
    }

    private static float ease(float t) { return t * t * (3f - 2f * t); }

    private void setMesh(float half, int h, boolean rightSide, float cosine, float n) {
        float sign = rightSide ? 1f : -1f;
        for (int row = 0; row <= 20; row++) {
            float v = row / 20f;
            for (int col = 0; col <= 20; col++) {
                float u = col / 20f;
                float distance = rightSide ? u : 1f - u;
                float perspective = distance * cosine / (1 + .43f * n * distance);
                float x = half + sign * half * perspective;
                float verticalScale = 1f - .166f * n * distance;
                float y = h * (.5f + (v - .5f) * verticalScale);
                int index = 2 * (row * 21 + col);
                mesh[index] = x;
                mesh[index + 1] = y;
            }
        }
    }

    private void ensureBitmaps(int w, int h) {
        if (w < 2 || h < 2) return;
        String uri = context.getSharedPreferences(PREFS, 0).getString(IMAGE, "");
        if (uri == null) uri = "";
        if (scene != null && w == width && h == height && uri.equals(lastUri)) return;
        invalidateArtwork();
        width = w;
        height = h;
        lastUri = uri;
        scene = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(scene);
        drawDefaultBackground(c, w, h);
        if (!uri.isEmpty()) {
            try (InputStream input = context.getContentResolver().openInputStream(Uri.parse(uri))) {
                if (input != null) {
                    BitmapFactory.Options bounds = new BitmapFactory.Options();
                    bounds.inJustDecodeBounds = true;
                    try (InputStream boundStream = context.getContentResolver()
                            .openInputStream(Uri.parse(uri))) {
                        if (boundStream != null) BitmapFactory.decodeStream(boundStream, null, bounds);
                    }
                    int sample = 1;
                    while (bounds.outWidth > 0 && bounds.outHeight > 0 &&
                            (bounds.outWidth / sample > w * 2 || bounds.outHeight / sample > h * 2)) {
                        sample *= 2;
                    }
                    BitmapFactory.Options actual = new BitmapFactory.Options();
                    actual.inSampleSize = sample;
                    Bitmap photo = BitmapFactory.decodeStream(input, null, actual);
                    if (photo != null) {
                        float scale = Math.max(w / (float) photo.getWidth(), h / (float) photo.getHeight());
                        float dw = photo.getWidth() * scale;
                        float dh = photo.getHeight() * scale;
                        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                        c.drawBitmap(photo, null, new RectF((w - dw) / 2, (h - dh) / 2,
                                (w + dw) / 2, (h + dh) / 2), p);
                        photo.recycle();
                    }
                }
            } catch (Exception ignored) { /* Keep built-in scene when an image is unavailable. */ }
        }
        int half = w / 2;
        left = Bitmap.createBitmap(scene, 0, 0, half, h);
        right = Bitmap.createBitmap(scene, half, 0, w - half, h);
        blurLeft = blurry(left);
        blurRight = blurry(right);
    }

    private static Bitmap blurry(Bitmap original) {
        int w = original.getWidth(), h = original.getHeight();
        // Two-stage filtered upsampling gives a soft lens rather than a pixelated overlay.
        Bitmap small = Bitmap.createScaledBitmap(original, Math.max(1, w / 22),
                Math.max(1, h / 22), true);
        Bitmap medium = Bitmap.createScaledBitmap(small, Math.max(1, w / 5),
                Math.max(1, h / 5), true);
        Bitmap soft = Bitmap.createScaledBitmap(medium, w, h, true);
        if (small != original) small.recycle();
        if (medium != original) medium.recycle();
        return soft;
    }

    private void ensureNoise() {
        if (noise != null && !noise.isRecycled()) return;
        Random random = new Random(41012);
        int size = 96;
        int[] pixels = new int[size * size];
        for (int i = 0; i < pixels.length; i++) {
            pixels[i] = (random.nextBoolean() ? 0x12FFFFFF : 0x10000000);
        }
        noise = Bitmap.createBitmap(pixels, size, size, Bitmap.Config.ARGB_8888);
        noiseShader = new BitmapShader(noise, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
    }

    private static void drawDefaultBackground(Canvas c, int w, int h) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, w, h,
                new int[]{0xFF06131D, 0xFF113B64, 0xFF4E2D79, 0xFF140C27},
                new float[]{0f, .34f, .69f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(new RadialGradient(.18f * w, .30f * h, .72f * w,
                new int[]{0xD92FEEDE, 0x0059A0FF}, null, Shader.TileMode.CLAMP));
        c.drawCircle(.18f * w, .30f * h, .72f * w, p);
        p.setShader(new RadialGradient(.89f * w, .73f * h, .83f * w,
                new int[]{0xBDEE5AC4, 0x00F95799}, null, Shader.TileMode.CLAMP));
        c.drawCircle(.89f * w, .73f * h, .83f * w, p);
        Random random = new Random(4101);
        p.setShader(null);
        for (int i = 0; i < 110; i++) {
            p.setColor(0x66FFFFFF);
            c.drawCircle(random.nextFloat() * w, random.nextFloat() * h,
                    .5f + random.nextFloat() * 1.9f, p);
        }
        p.setColor(0x33FFFFFF);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(w * .0023f);
        for (int i = 1; i <= 4; i++) {
            float radius = w * (.24f + .17f * i);
            c.drawCircle(w * .52f, h * .50f, radius, p);
        }
        p.setStyle(Paint.Style.FILL);
    }
}

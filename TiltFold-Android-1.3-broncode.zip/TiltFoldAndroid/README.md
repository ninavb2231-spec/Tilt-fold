# TiltFold Frost 1.3 🫧

Privé, offline live wallpaper voor Android met tilt-gestuurde, **toenemende frosted blur**.

### Wat is nieuw
- Geen hard middennaadje of paneelranden: de originele foto blijft doorlopend.
- De hoeveelheid onscherpte neemt toe naarmate de kanteling groter wordt.
- Drie voorgerenderde blur-niveaus, geleidelijk gecombineerd met een brede, vloeiende fade.
- Subtiele reflecties en een koelwit glasfilter, zonder harde reflectielijnen.
- Rustigere veeranimatie; maximaal ~60 tekenframes per seconde wanneer nodig.
- Geen internet, toegankelijkheidsrechten, schermopname, Shizuku of Restricted settings.
- Dit effect geldt alleen voor de wallpaper, niet voor icoontjes of appvensters.

### Bouwen via GitHub op je telefoon

1. Upload de ZIP `TiltFold-Android-1.3-broncode.zip` in de root van je bestaande repository.
2. Vervang `.github/workflows/build-apk.yml` in je repository door het meegeleverde bestand
   `build-apk-voor-GitHub.yml` buiten de ZIP (of de inhoud uit `.github/workflows/build-apk.yml` in de ZIP).
3. Ga naar Actions > `Bouw TiltFold Frost 1.3 APK` > Run workflow.
4. Download artifact `TiltFold-FROST-1.3-APK`, pak uit en installeer de APK.

Dit is een **afzonderlijke app** met ID `nl.tiltfold.frostfade`: je werkende 1.2 blijft bestaan.
De broncode is gecontroleerd op structuur en permissies; bouwen en installeren moet via GitHub worden bevestigd.

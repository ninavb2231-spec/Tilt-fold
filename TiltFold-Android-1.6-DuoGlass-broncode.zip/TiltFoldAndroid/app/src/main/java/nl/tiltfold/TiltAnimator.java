package nl.tiltfold;

import android.os.SystemClock;

/** Display-rate underdamped spring: responsive movement, gentle settle. */
final class TiltAnimator {
    private float position;
    private float velocity;
    private long lastFrameNanos;

    float getDegrees() { return position; }
    float getVelocity() { return velocity; }

    void snapTo(float degrees) {
        position = degrees;
        velocity = 0f;
        lastFrameNanos = 0L;
    }

    boolean step(float target) {
        long now = SystemClock.elapsedRealtimeNanos();
        if (lastFrameNanos == 0L) {
            lastFrameNanos = now;
            return Math.abs(target-position) > .035f;
        }
        float dt = Math.max(.001f, Math.min(.04f, (now-lastFrameNanos)*1e-9f));
        lastFrameNanos = now;
        if (Math.abs(target-position) < .035f && Math.abs(velocity) < .13f) {
            position=target;
            velocity=0f;
            return false;
        }
        float omega = 12.2f;
        float zeta = .83f;
        float wd = omega*(float)Math.sqrt(1-zeta*zeta);
        float x = position-target;
        float c = (float)Math.cos(wd*dt);
        float s = (float)Math.sin(wd*dt);
        float decay = (float)Math.exp(-zeta*omega*dt);
        float t = (velocity+zeta*omega*x)/wd;
        float nx = decay*(x*c+t*s);
        float nv = decay*(velocity*c - (zeta*omega*velocity+omega*omega*x)/wd*s);
        position=target+nx;
        velocity=nv;
        return Math.abs(target-position)>.035f || Math.abs(velocity)>.13f;
    }
}

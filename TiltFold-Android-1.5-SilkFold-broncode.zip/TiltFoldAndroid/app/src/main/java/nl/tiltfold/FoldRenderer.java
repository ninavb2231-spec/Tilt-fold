package nl.tiltfold;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.net.Uri;

import java.io.InputStream;
import java.util.Random;

/**
 * TiltFold 1.5 SilkFold: original strip-mesh interpretation of folding glass.
 * 3D-inspired 2D projection using a continuous image mesh hinged at the bottom.
 * The wallpaper is never captured and no special permissions are requested.
 */
final class FoldRenderer {
    static final String PREFS = "tiltfold";
    static final String IMAGE = "image";
    static final String STRENGTH = "strength";
    static final String REVERSED = "reversed";
    static final String GLASS = "glass_level";
    static final String DEPTH = "fold_depth";

    // Mesh vertices are connected. There is no separate left or right panel, and no centre seam.
    private static final int COLUMNS = 12;
    private static final int ROWS = 64;
    private final float[] vertices = new float[(COLUMNS + 1) * (ROWS + 1) * 2];
    private final int[] softColors = new int[(COLUMNS + 1) * (ROWS + 1)];
    private final int[] strongColors = new int[(COLUMNS + 1) * (ROWS + 1)];
    private final float[] projectedY = new float[ROWS + 1];
    private final float[] projectedScale = new float[ROWS + 1];
    private final float[] projectedOffset = new float[ROWS + 1];

    private final Context context;
    private final Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint glassPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Path silhouette = new Path();
    private Bitmap scene, blurSoft, blurMedium, blurStrong, noise;
    private BitmapShader softShader, mediumShader, strongShader, noiseShader;
    private int width, height;
    private String lastUri;

    FoldRenderer(Context context) { this.context = context.getApplicationContext(); }

    void invalidateArtwork() {
        recycle(scene); recycle(blurSoft); recycle(blurMedium); recycle(blurStrong);
        scene = blurSoft = blurMedium = blurStrong = null;
        softShader = mediumShader = strongShader = null;
    }

    private static void recycle(Bitmap bmp) { if (bmp != null && !bmp.isRecycled()) bmp.recycle(); }
    private static float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }
    private static float smooth(float x) { x = clamp(x); return x*x*(3f-2f*x); }
    private static int opacity(float a) {
        return (Math.round(clamp(a) * 255f) << 24) | 0x00FFFFFF;
    }

    /**
     * Continuous bending glass. Each row is projected from the same bottom hinge,
     * with a smoothly increasing tangent angle and a fixed viewer perspective.
     * There are no separately-rendered panels or a line through the image.
     */
    void draw(Canvas canvas, float degrees, float speed) {
        final int w = canvas.getWidth();
        final int h = canvas.getHeight();
        ensureBitmaps(w, h);
        if (scene == null) return;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, 0);
        final float sensitivity = prefs.getInt(STRENGTH, 100) / 100f;
        final float frost = clamp(prefs.getInt(GLASS, 85) / 100f);
        final float bend = clamp(prefs.getInt(DEPTH, 78) / 100f);
        if (prefs.getBoolean(REVERSED, false)) degrees = -degrees;
        final float sign = degrees >= 0 ? 1f : -1f;
        // A gently eased response with a perceptual dead zone around neutral.
        final float tilt = clamp((Math.abs(degrees) * sensitivity - 1.4f) / 47f);
        final float fold = tilt * tilt * (3f - 2f * tilt);
        imagePaint.setShader(null);
        imagePaint.setColor(Color.WHITE);
        imagePaint.setAlpha(255);
        if (fold < .00002f) {
            canvas.drawBitmap(scene, 0, 0, imagePaint);
            return;
        }

        // A soft, defocused dark desktop remains BEHIND the receding sheet.
        canvas.drawBitmap(blurStrong, 0, 0, imagePaint);
        glassPaint.setShader(new LinearGradient(0, 0, 0, h,
                new int[] {0xFF040914, 0xFF10152A, 0xFF0D0E1B},
                new float[] {0f, .58f, 1f}, Shader.TileMode.CLAMP));
        glassPaint.setAlpha(Math.round(135f + 85f * fold));
        canvas.drawRect(0, 0, w, h, glassPaint);
        glassPaint.setAlpha(255);
        glassPaint.setShader(null);

        // The real bend: integrate a continuous 3D tangent from the bottom edge.
        // Tilt away from the viewer causes foreshortening AND the top becomes
        // narrower. A simple scale/translate animation cannot achieve this.
        final float maxAngle = (float) Math.toRadians(20f + 67f*bend) * fold;
        final double worldStep = h / (double) ROWS;
        final float focal = h * (2.05f - .60f*bend);
        double y = 0.0;
        double z = 0.0;
        for (int bottomRow = 0; bottomRow <= ROWS; bottomRow++) {
            if (bottomRow > 0) {
                final float u = (bottomRow-.5f) / ROWS;
                // A flexible screen: almost flat at the hinge, curling toward the top.
                final double theta = maxAngle * Math.pow(u, .55 + 1.25*(1f-bend));
                y += worldStep * Math.cos(theta);
                z += worldStep * Math.sin(theta);
            }
            int row = ROWS-bottomRow;
            float perspective = (float)(focal / (focal + z));
            projectedY[row] = h - (float)y * perspective;
            projectedScale[row] = perspective;
            projectedOffset[row] = sign * (float)(z/h)*w*.035f;
        }

        final float kinetic = clamp(Math.abs(speed) / 105f);
        final float motionFrost = frost * clamp(.15f*kinetic + .90f*fold);
        for (int row = 0; row <= ROWS; row++) {
            final float topness = 1f - row/(float)ROWS;
            final float topFrost = topness*topness*(3f - 2f*topness);
            final float opacity = motionFrost * (.15f + .85f*topFrost);
            // Non-linear soft-to-strong blur. The top goes milky first.
            final float mediumAlpha = clamp(opacity * (.62f + .10f*kinetic));
            final float heavyAlpha = clamp(opacity * (.16f + .76f*fold + .12f*kinetic));
            final int mediumTint = opacity(mediumAlpha);
            final int heavyTint = opacity(heavyAlpha);
            for (int col = 0; col <= COLUMNS; col++) {
                final int i = row*(COLUMNS + 1) + col;
                final float x = w*col/(float)COLUMNS;
                vertices[2*i] = w*.5f + (x-w*.5f)*projectedScale[row] + projectedOffset[row];
                vertices[2*i+1] = projectedY[row];
                softColors[i] = mediumTint;
                strongColors[i] = heavyTint;
            }
        }

        // Draw both the sharp image and the progressive frosted surfaces using
        // EXACTLY the same connected mesh. No discontinuity or dividing line.
        canvas.drawBitmapMesh(scene, COLUMNS, ROWS, vertices, 0, null, 0, imagePaint);
        if (motionFrost > .005f) {
            canvas.drawBitmapMesh(blurMedium, COLUMNS, ROWS, vertices, 0, softColors, 0, imagePaint);
            canvas.drawBitmapMesh(blurStrong, COLUMNS, ROWS, vertices, 0, strongColors, 0, imagePaint);
        }

        silhouette.reset();
        silhouette.moveTo(vertices[0], vertices[1]);
        for (int row = 1; row <= ROWS; row++) {
            int i = 2*row*(COLUMNS+1);
            silhouette.lineTo(vertices[i], vertices[i+1]);
        }
        for (int row = ROWS; row >= 0; row--) {
            int i = 2*(row*(COLUMNS+1)+COLUMNS);
            silhouette.lineTo(vertices[i], vertices[i+1]);
        }
        silhouette.close();
        canvas.save();
        canvas.clipPath(silhouette);
        final float top = projectedY[0];
        // Lambert-inspired shadow: parts facing away lose light smoothly.
        glassPaint.setShader(new LinearGradient(0f, top, 0f, h,
                new int[] { Color.argb(Math.round(176*fold), 0, 5, 16),
                            Color.argb(Math.round(100*fold), 5, 13, 30),
                            Color.argb(Math.round(30*fold), 15, 23, 36),
                            Color.TRANSPARENT },
                new float[] {0f, .31f, .71f, 1f}, Shader.TileMode.CLAMP));
        glassPaint.setAlpha(255);
        canvas.drawRect(0, 0, w, h, glassPaint);

        // A wide, diagonal Fresnel sheen. It must NEVER look like a hinge line.
        final float sheen = .46f + .17f*sign*fold;
        glassPaint.setShader(new LinearGradient(w*(sheen-.65f), top,
                w*(sheen+.58f), h,
                new int[] {Color.TRANSPARENT,
                           Color.argb(Math.round(12f*fold*frost), 242, 250, 255),
                           Color.argb(Math.round(62f*fold*frost), 235, 247, 255),
                           Color.argb(Math.round(17f*fold*frost), 210, 228, 250),
                           Color.TRANSPARENT},
                new float[]{0f,.26f,.51f,.73f,1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, glassPaint);

        // Semi-translucent opal haze, not a solid white rectangle.
        glassPaint.setShader(new LinearGradient(0, top, 0, h,
                new int[]{Color.argb(Math.round(56*fold*frost), 228, 236, 255),
                          Color.argb(Math.round(17*fold*frost), 212, 228, 249),
                          Color.TRANSPARENT},
                new float[]{0f,.43f,1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, glassPaint);
        glassPaint.setShader(null);
        canvas.restore();
    }

    private void ensureBitmaps(int w, int h) {
        if (w < 2 || h < 2) return;
        String uri = context.getSharedPreferences(PREFS, 0).getString(IMAGE, "");
        if (uri == null) uri = "";
        if (scene != null && w == width && h == height && uri.equals(lastUri)) return;
        invalidateArtwork();
        width = w;
        height = h;
        lastUri = uri;
        scene = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(scene);
        drawDefaultBackground(c, w, h);
        if (!uri.isEmpty()) {
            try (InputStream input = context.getContentResolver().openInputStream(Uri.parse(uri))) {
                if (input != null) {
                    BitmapFactory.Options bounds = new BitmapFactory.Options();
                    bounds.inJustDecodeBounds = true;
                    try (InputStream boundStream = context.getContentResolver()
                            .openInputStream(Uri.parse(uri))) {
                        if (boundStream != null) BitmapFactory.decodeStream(boundStream, null, bounds);
                    }
                    int sample = 1;
                    while (bounds.outWidth > 0 && bounds.outHeight > 0 &&
                            (bounds.outWidth / sample > w * 2 || bounds.outHeight / sample > h * 2)) {
                        sample *= 2;
                    }
                    BitmapFactory.Options actual = new BitmapFactory.Options();
                    actual.inSampleSize = sample;
                    Bitmap photo = BitmapFactory.decodeStream(input, null, actual);
                    if (photo != null) {
                        float scale = Math.max(w / (float) photo.getWidth(), h / (float) photo.getHeight());
                        float dw = photo.getWidth() * scale;
                        float dh = photo.getHeight() * scale;
                        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                        c.drawBitmap(photo, null, new RectF((w - dw) / 2, (h - dh) / 2,
                                (w + dw) / 2, (h + dh) / 2), p);
                        photo.recycle();
                    }
                }
            } catch (Exception ignored) { /* Keep built-in scene when an image is unavailable. */ }
        }
        blurSoft = blurry(scene, 9);
        blurMedium = blurry(scene, 25);
        blurStrong = blurry(scene, 55);
        softShader = new BitmapShader(blurSoft, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        mediumShader = new BitmapShader(blurMedium, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        strongShader = new BitmapShader(blurStrong, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
    }

    /** Pre-render blur textures once per artwork change, never inside a frame. */
    private static Bitmap blurry(Bitmap original, int radius) {
        int w = original.getWidth(), h = original.getHeight();
        int factor = 5;
        int sw = Math.max(1, w/factor), sh = Math.max(1, h/factor);
        Bitmap scaled = Bitmap.createScaledBitmap(original, sw, sh, true);
        int[] pix = new int[sw*sh];
        int[] tmp = new int[sw*sh];
        scaled.getPixels(pix, 0, sw, 0, 0, sw, sh);
        int r = Math.max(1, radius/factor);
        for (int pass=0; pass<3; pass++) {
            // Separable box blur repeated three times approximates a Gaussian.
            for (int yy=0; yy<sh; yy++) for (int xx=0; xx<sw; xx++) {
                int red=0, green=0, blue=0, count=0;
                for (int k=-r;k<=r;k++) {
                    int px = Math.max(0, Math.min(sw-1, xx+k));
                    int c = pix[yy*sw+px];
                    red += (c>>>16)&255; green += (c>>>8)&255; blue+=c&255; count++;
                }
                tmp[yy*sw+xx] = 0xFF000000 | ((red/count)<<16) | ((green/count)<<8) | (blue/count);
            }
            for (int yy=0; yy<sh; yy++) for (int xx=0; xx<sw; xx++) {
                int red=0, green=0, blue=0, count=0;
                for (int k=-r;k<=r;k++) {
                    int py = Math.max(0, Math.min(sh-1, yy+k));
                    int c = tmp[py*sw+xx];
                    red += (c>>>16)&255; green += (c>>>8)&255; blue+=c&255; count++;
                }
                pix[yy*sw+xx] = 0xFF000000 | ((red/count)<<16) | ((green/count)<<8) | (blue/count);
            }
        }
        Bitmap small = Bitmap.createBitmap(pix, sw, sh, Bitmap.Config.ARGB_8888);
        Bitmap result = Bitmap.createScaledBitmap(small, w, h, true);
        scaled.recycle(); small.recycle();
        return result;
    }

    private void ensureNoise() {
        if (noise != null && !noise.isRecycled()) return;
        Random random = new Random(41012);
        int size = 96;
        int[] pixels = new int[size * size];
        for (int i = 0; i < pixels.length; i++) {
            pixels[i] = (random.nextBoolean() ? 0x0FFFFFFF : 0x0A000000);
        }
        noise = Bitmap.createBitmap(pixels, size, size, Bitmap.Config.ARGB_8888);
        noiseShader = new BitmapShader(noise, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
    }

    private static void drawDefaultBackground(Canvas c, int w, int h) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, w, h,
                new int[]{0xFF06131D, 0xFF113B64, 0xFF4E2D79, 0xFF140C27},
                new float[]{0f, .34f, .69f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(new RadialGradient(.18f * w, .30f * h, .72f * w,
                new int[]{0xD92FEEDE, 0x0059A0FF}, null, Shader.TileMode.CLAMP));
        c.drawCircle(.18f * w, .30f * h, .72f * w, p);
        p.setShader(new RadialGradient(.89f * w, .73f * h, .83f * w,
                new int[]{0xBDEE5AC4, 0x00F95799}, null, Shader.TileMode.CLAMP));
        c.drawCircle(.89f * w, .73f * h, .83f * w, p);
        Random random = new Random(4101);
        p.setShader(null);
        for (int i = 0; i < 110; i++) {
            p.setColor(0x66FFFFFF);
            c.drawCircle(random.nextFloat() * w, random.nextFloat() * h,
                    .5f + random.nextFloat() * 1.9f, p);
        }
        p.setColor(0x33FFFFFF);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(w * .0023f);
        for (int i = 1; i <= 4; i++) {
            float radius = w * (.24f + .17f * i);
            c.drawCircle(w * .52f, h * .50f, radius, p);
        }
        p.setStyle(Paint.Style.FILL);
    }
}

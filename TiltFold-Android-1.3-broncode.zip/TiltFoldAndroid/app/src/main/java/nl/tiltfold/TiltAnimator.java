package nl.tiltfold;

import android.os.SystemClock;

/**
 * A critically damped spring. Sensor events change the target; the UI draws intermediate
 * positions on display frames. This keeps motion fluid even when sensor readings are uneven.
 */
final class TiltAnimator {
    private float position;
    private float velocity;
    private long lastFrameNanos;

    float getDegrees() { return position; }

    void snapTo(float degrees) {
        position = degrees;
        velocity = 0f;
        lastFrameNanos = 0L;
    }

    /** Returns true while another animation frame is needed. */
    boolean step(float target) {
        long now = SystemClock.elapsedRealtimeNanos();
        if (lastFrameNanos == 0L) {
            lastFrameNanos = now;
            return Math.abs(target - position) > .03f;
        }
        float dt = (now - lastFrameNanos) * 1e-9f;
        lastFrameNanos = now;
        dt = Math.max(0.001f, Math.min(.05f, dt));
        if (Math.abs(target - position) <= .03f && Math.abs(velocity) <= .08f) {
            position = target;
            velocity = 0;
            return false;
        }
        final float omega = 13.8f;
        float difference = position - target;
        float temporary = velocity + omega * difference;
        float damping = (float) Math.exp(-omega * dt);
        position = target + (difference + temporary * dt) * damping;
        velocity = (velocity - omega * temporary * dt) * damping;
        return Math.abs(target - position) > .03f || Math.abs(velocity) > .08f;
    }
}

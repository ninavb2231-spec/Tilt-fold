package nl.tiltfold;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RuntimeShader;
import android.graphics.Shader;
import android.os.Build;

/**
 * Wallpaper-friendly GPU adaptation of the public MIT-licensed Duo/Open family
 * glass model: one full-screen plane, hinge-distance based projection, variable
 * blur proportional to separation and light attenuation. The implementation
 * below is newly written for a regular non-foldable phone and does NOT include
 * any accessibility, Shizuku, screen-capture or overlay services.
 *
 * Inspiration and attribution: marcoazeem/duo-open (MIT); see UPSTREAM.md.
 */
final class DuoGlassShader {
    private static final String AGSL = """
        uniform shader photo;
        uniform float2 size;
        uniform float fold;
        uniform float direction;
        uniform float frost;
        uniform float depth;
        uniform float motion;
        uniform float vertical;

        half4 main(float2 p) {
            float2 uv = clamp(p / size, float2(0.0), float2(1.0));
            // Continuous, full-viewport projection: no cut-out sheet or hard edge.
            float anchor = direction >= 0.0 ? 0.0 : 1.0;
            float gap = vertical > 0.5 ? (1.0 - uv.y) : abs(uv.x - anchor);
            float bend = smoothstep(0.0, 1.0, clamp(fold, 0.0, 1.0));
            float spatial = bend * (0.25 + 0.75 * depth);
            float g2 = gap * gap;

            // Fixed scene viewed through a rotating virtual pane. Sampling
            // stays full-screen as perspective moves, unlike inset-card renders.
            float2 offset = float2(0.0, 0.0);
            if (vertical > 0.5) {
                offset.y = spatial * 0.055 * g2;
                offset.x = (uv.x - 0.5) * spatial * 0.022 * gap;
            } else {
                offset.x = (uv.x - anchor) * spatial * 0.074 * gap;
                offset.y = (uv.y - 0.5) * spatial * 0.025 * gap;
            }
            float2 source = clamp((uv + offset) * size, float2(0.0), size);

            // The frost is generated on the actual warped image. The rotation
            // gap determines the local blur radius, so the anchored edge stays
            // clear while the far edge dissolves into diffused glass.
            float blur = min(35.0, (2.0 + 31.0 * depth) *
                             pow(bend, 0.8) * (0.10 + 0.90 * gap) * frost);
            blur *= 1.0 + 0.14 * clamp(motion, 0.0, 1.0);
            half4 col = photo.eval(source);
            if (blur > 0.35) {
                half4 sum = half4(0.0);
                // Golden-angle disk blur, deterministic and bounded at 13 taps.
                for (int i = 0; i < 13; ++i) {
                    float r = sqrt((float(i) + 0.5) / 13.0);
                    float a = float(i) * 2.39996323;
                    float2 o = float2(cos(a), sin(a)) * (r * blur);
                    sum += photo.eval(clamp(source + o, float2(0.0), size));
                }
                col = sum / 13.0;
            }

            float glass = bend * frost * (0.10 + 0.90 * gap);
            float lambert = 1.0 - 0.32 * spatial * gap;
            float reflection = exp(-pow((gap - (0.34 + 0.28 * bend)) / 0.22, 2.0));
            float shimmer = 0.075 * glass * reflection;
            float opal = 0.15 * glass * pow(gap, 0.7);
            float3 rgb = float3(col.rgb) * lambert;
            rgb = mix(rgb, float3(0.82, 0.89, 0.98), opal);
            rgb += float3(0.78, 0.87, 1.0) * shimmer;
            // Micro-grain makes the frost feel optical instead of a white wash.
            float grain = fract(sin(dot(p, float2(12.9898, 78.233))) * 43758.5453);
            rgb += (grain - 0.5) * 0.012 * glass;
            return half4(half3(clamp(rgb, 0.0, 1.0)), 1.0);
        }
        """;

    private RuntimeShader shader;
    private Bitmap bound;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private boolean failed;

    boolean draw(Canvas canvas, Bitmap photo, float fold, float dir,
                 float frost, float depth, float motion, boolean vertical) {
        if (Build.VERSION.SDK_INT < 33 || !canvas.isHardwareAccelerated() || failed) return false;
        try {
            if (shader == null) shader = new RuntimeShader(AGSL);
            if (bound != photo) {
                shader.setInputShader("photo", new BitmapShader(photo, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
                bound = photo;
            }
            shader.setFloatUniform("size", (float) canvas.getWidth(), (float) canvas.getHeight());
            shader.setFloatUniform("fold", fold);
            shader.setFloatUniform("direction", dir);
            shader.setFloatUniform("frost", frost);
            shader.setFloatUniform("depth", depth);
            shader.setFloatUniform("motion", motion);
            shader.setFloatUniform("vertical", vertical ? 1.0f : 0.0f);
            paint.setShader(shader);
            paint.setAlpha(255);
            canvas.drawRect(0, 0, canvas.getWidth(), canvas.getHeight(), paint);
            return true;
        } catch (RuntimeException | LinkageError ex) {
            android.util.Log.e("TiltFold", "GPU shader unavailable; fallback to Canvas", ex);
            failed = true;
            return false;
        }
    }

    void invalidate() { bound = null; }
}

package nl.tiltfold;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.net.Uri;

import java.io.InputStream;
import java.util.Random;

/** A 2D hinged-glass illusion rendered without privileged Android permissions. */
final class FoldRenderer {
    static final String PREFS = "tiltfold";
    static final String IMAGE = "image";
    static final String STRENGTH = "strength";
    static final String REVERSED = "reversed";

    private final Context context;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private Bitmap scene, left, right, blurLeft, blurRight;
    private int width, height;
    private String lastUri;

    FoldRenderer(Context context) { this.context = context.getApplicationContext(); }

    void invalidateArtwork() {
        if (scene != null) scene.recycle();
        if (left != null) left.recycle();
        if (right != null) right.recycle();
        if (blurLeft != null) blurLeft.recycle();
        if (blurRight != null) blurRight.recycle();
        scene = left = right = blurLeft = blurRight = null;
    }

    void draw(Canvas canvas, float tiltDegrees) {
        int w = canvas.getWidth(), h = canvas.getHeight();
        ensureBitmaps(w, h);
        if (scene == null) return;
        if (context.getSharedPreferences(PREFS, 0).getBoolean(REVERSED, false)) tiltDegrees = -tiltDegrees;
        float sensitivity = context.getSharedPreferences(PREFS, 0).getInt(STRENGTH, 100) / 100f;
        float normalized = Math.min(1f, Math.abs(tiltDegrees) * sensitivity / 48f);
        // The panel is drawn on a mesh, hinged at the centre. Left or right follows the direction.
        canvas.drawColor(Color.rgb(9, 11, 24));
        if (normalized < .008f) {
            paint.setAlpha(255);
            canvas.drawBitmap(scene, 0, 0, paint);
            return;
        }
        boolean moveRight = tiltDegrees >= 0;
        int half = w / 2;
        canvas.save();
        if (moveRight) canvas.clipRect(0, 0, half, h);
        else canvas.clipRect(half, 0, w, h);
        paint.setAlpha(255);
        canvas.drawBitmap(scene, 0, 0, paint);
        canvas.restore();

        float angle = (float) Math.toRadians(normalized * 78);
        float cosine = (float) Math.cos(angle);
        float[] vertices = makeMesh(half, h, moveRight, cosine, normalized);
        Bitmap panel = moveRight ? right : left;
        Bitmap blur = moveRight ? blurRight : blurLeft;
        paint.setAlpha(255);
        canvas.drawBitmapMesh(panel, 20, 20, vertices, 0, null, 0, paint);
        paint.setAlpha(Math.min(225, Math.round(normalized * 215)));
        canvas.drawBitmapMesh(blur, 20, 20, vertices, 0, null, 0, paint);
        paint.setAlpha(255);

        // Shade the receding panel, with a soft highlight near the crease.
        float extent = half * cosine / (1 + .48f * normalized);
        float end = moveRight ? half + extent : half - extent;
        Paint shade = new Paint(Paint.ANTI_ALIAS_FLAG);
        shade.setShader(new LinearGradient(half, 0, end, 0,
                new int[]{0x26FFFFFF, 0x52040A1B, 0xD9000410}, null, Shader.TileMode.CLAMP));
        Path panelArea = new Path();
        panelArea.moveTo(half, 0);
        float squeeze = .095f * normalized;
        panelArea.lineTo(end, h * squeeze);
        panelArea.lineTo(end, h * (1 - squeeze));
        panelArea.lineTo(half, h);
        panelArea.close();
        canvas.drawPath(panelArea, shade);

        shade.setShader(new LinearGradient(half - 7, 0, half + 7, 0,
                new int[]{0x00000000, 0xAD000012, 0x80FFFFFF, 0x00000000},
                new float[]{0f, .40f, .53f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(half - 7, 0, half + 7, h, shade);
    }

    private static float[] makeMesh(int half, int h, boolean moveRight, float cosine, float amount) {
        int cells = 20;
        float[] vertices = new float[(cells + 1) * (cells + 1) * 2];
        float direction = moveRight ? 1 : -1;
        for (int row = 0; row <= cells; row++) {
            float v = row / (float) cells;
            for (int col = 0; col <= cells; col++) {
                float sourceU = col / (float) cells;
                float distance = moveRight ? sourceU : 1f - sourceU;
                float projected = distance * cosine / (1f + .48f * amount * distance);
                float x = half + direction * half * projected;
                float verticalScale = 1f - .19f * amount * distance;
                float y = h * (.5f + (v - .5f) * verticalScale);
                int index = 2 * (row * (cells + 1) + col);
                vertices[index] = x;
                vertices[index + 1] = y;
            }
        }
        return vertices;
    }

    private void ensureBitmaps(int w, int h) {
        if (w < 2 || h < 2) return;
        String uri = context.getSharedPreferences(PREFS, 0).getString(IMAGE, "");
        if (uri == null) uri = "";
        if (scene != null && w == width && h == height && uri.equals(lastUri)) return;
        invalidateArtwork();
        width = w;
        height = h;
        lastUri = uri;
        scene = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(scene);
        drawDefaultBackground(c, w, h);
        if (!uri.isEmpty()) {
            try (InputStream input = context.getContentResolver().openInputStream(Uri.parse(uri))) {
                if (input != null) {
                    BitmapFactory.Options opts = new BitmapFactory.Options();
                    opts.inJustDecodeBounds = true;
                    // Use separate streams because bounds decoding consumes the stream.
                    try (InputStream boundStream = context.getContentResolver().openInputStream(Uri.parse(uri))) {
                        if (boundStream != null) BitmapFactory.decodeStream(boundStream, null, opts);
                    }
                    int sample = 1;
                    while (opts.outWidth / sample > w * 2 || opts.outHeight / sample > h * 2) sample *= 2;
                    BitmapFactory.Options actual = new BitmapFactory.Options();
                    actual.inSampleSize = sample;
                    Bitmap photo = BitmapFactory.decodeStream(input, null, actual);
                    if (photo != null) {
                        float scale = Math.max(w / (float) photo.getWidth(), h / (float) photo.getHeight());
                        float dw = photo.getWidth() * scale, dh = photo.getHeight() * scale;
                        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                        c.drawBitmap(photo, null, new RectF((w - dw) / 2, (h - dh) / 2,
                                (w + dw) / 2, (h + dh) / 2), p);
                        photo.recycle();
                    }
                }
            } catch (Exception ignored) { /* Retain the bundled abstract scene. */ }
        }
        int half = w / 2;
        left = Bitmap.createBitmap(scene, 0, 0, half, h);
        right = Bitmap.createBitmap(scene, half, 0, half, h);
        blurLeft = blurry(left);
        blurRight = blurry(right);
    }

    private static Bitmap blurry(Bitmap original) {
        int w = original.getWidth(), h = original.getHeight();
        Bitmap small = Bitmap.createScaledBitmap(original, Math.max(1, w / 30),
                Math.max(1, h / 30), true);
        Bitmap soft = Bitmap.createScaledBitmap(small, w, h, true);
        if (small != original) small.recycle();
        return soft;
    }

    private static void drawDefaultBackground(Canvas c, int w, int h) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, w, h,
                new int[]{0xFF06131D, 0xFF113B64, 0xFF4E2D79, 0xFF140C27},
                new float[]{0f, .34f, .69f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(new RadialGradient(.18f * w, .30f * h, .72f * w,
                new int[]{0xD92FEEDE, 0x0059A0FF}, null, Shader.TileMode.CLAMP));
        c.drawCircle(.18f * w, .30f * h, .72f * w, p);
        p.setShader(new RadialGradient(.89f * w, .73f * h, .83f * w,
                new int[]{0xBDEE5AC4, 0x00F95799}, null, Shader.TileMode.CLAMP));
        c.drawCircle(.89f * w, .73f * h, .83f * w, p);
        Random random = new Random(4101);
        p.setShader(null);
        for (int i = 0; i < 110; i++) {
            p.setColor(0x66FFFFFF);
            c.drawCircle(random.nextFloat() * w, random.nextFloat() * h,
                    .5f + random.nextFloat() * 1.9f, p);
        }
        p.setColor(0x33FFFFFF);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(w * .0023f);
        for (int i = 1; i <= 4; i++) {
            float radius = w * (.24f + .17f * i);
            c.drawCircle(w * .52f, h * .50f, radius, p);
        }
        p.setStyle(Paint.Style.FILL);
    }
}

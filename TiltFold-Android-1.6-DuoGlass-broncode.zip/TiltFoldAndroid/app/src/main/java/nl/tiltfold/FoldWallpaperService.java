package nl.tiltfold;

import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

public final class FoldWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new FoldEngine(); }

    private final class FoldEngine extends Engine implements SharedPreferences.OnSharedPreferenceChangeListener {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final FoldRenderer renderer = new FoldRenderer(FoldWallpaperService.this);
        private final TiltAnimator animator = new TiltAnimator();
        private final TiltTracker tracker = new TiltTracker(FoldWallpaperService.this, this::scheduleFrame);
        private final SharedPreferences preferences = getSharedPreferences(FoldRenderer.PREFS, 0);
        private boolean visible;
        private boolean framePending;
        private final Runnable drawTask = () -> {
            framePending = false;
            if (!visible) return;
            boolean moving = animator.step(tracker.getDegrees());
            render();
            if (moving) scheduleFrame();
        };

        FoldEngine() {
            preferences.registerOnSharedPreferenceChangeListener(this);
            setTouchEventsEnabled(false);
        }

        private void scheduleFrame() {
            if (!visible || framePending) return;
            framePending = true;
            handler.postDelayed(drawTask, 16); // Up to ~60 fps, only while moving.
        }

        private void render() {
            if (!visible) return;
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                // lockCanvas() is software-only on many launchers. The real
                // AGSL glass projection needs a hardware accelerated canvas.
                try { canvas = holder.lockHardwareCanvas(); }
                catch (RuntimeException error) {
                    canvas = holder.lockCanvas();
                }
                if (canvas != null) renderer.draw(canvas, animator.getDegrees(), animator.getVelocity());
            } catch (Exception ignored) {
                // Wallpaper surfaces can disappear during launcher transitions.
            } finally {
                if (canvas != null) {
                    try { holder.unlockCanvasAndPost(canvas); } catch (Exception ignored) {}
                }
            }
        }

        @Override public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            handler.removeCallbacks(drawTask);
            framePending = false;
            if (visible) {
                renderer.invalidateArtwork();
                animator.snapTo(tracker.getDegrees());
                tracker.start();
                render();
            } else tracker.stop();
        }

        @Override public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            renderer.invalidateArtwork();
            if (visible) render();
        }

        @Override public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {
            if (FoldRenderer.IMAGE.equals(key)) renderer.invalidateArtwork();
            if (TiltTracker.CALIBRATION.equals(key) ||
                    TiltTracker.CALIBRATION_PITCH.equals(key) ||
                    TiltTracker.PITCH_MODE.equals(key)) {
                tracker.reloadCalibration();
                animator.snapTo(0f);
            }
            scheduleFrame();
        }

        @Override public void onDestroy() {
            visible = false;
            handler.removeCallbacks(drawTask);
            tracker.stop();
            renderer.invalidateArtwork();
            preferences.unregisterOnSharedPreferenceChangeListener(this);
            super.onDestroy();
        }
    }
}

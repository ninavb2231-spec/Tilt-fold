# TiltFold 1.5 — SilkFold

Een zelfstandig installeerbare live wallpaper voor Android, geïnspireerd door de beweging van [iFold Mac](https://github.com/maheshj01/ifold-mac) (referentie, niet dezelfde code).

Nieuw: doorlopend 64-rijen 3D-mesh, een onderaan verankerde krulcurve, progressieve Gaussian-achtige frost die sterker wordt tijdens het kantelen, zachte lichtval, een fullscreen-voorvertoning en een instelbare laptopkantelrichting.

## Veiligheid en beperkingen

Geen internet-, accessibility-, schermopname- of Shizuku-toestemmingen. Alleen je eigen live achtergrond wordt gebogen; andere apps en iconen NIET. Daardoor is het effect niet hetzelfde als de volledige desktop-overlay van iFold Mac. Op sommige launchers wordt het beeld buiten de preview gedeeltelijk bedekt door iconen en widgets.

## Bouwen via GitHub

Upload **TiltFold-Android-1.5-SilkFold-broncode.zip** naar de root van je bestaande GitHub repository, en zet de bijgeleverde `build-apk.yml` in `.github/workflows/build-apk.yml`. Kies in Actions `Bouw nieuwste TiltFold APK` → `Run workflow`, download `TiltFold-NIEUWSTE-APK` en pak `TiltFold-1.5.apk` uit. De workflow kiest automatisch de ZIP met de hoogste versie in de repository, dus vanaf nu hoef je de workflow niet telkens aan te passen.

Deze versie gebruikt app-ID `nl.tiltfold.silkfold` en kan naast je vorige werkende versies worden geinstalleerd.
